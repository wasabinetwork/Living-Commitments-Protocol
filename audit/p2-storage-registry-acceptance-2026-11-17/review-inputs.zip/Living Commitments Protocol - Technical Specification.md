# Living Commitments Protocol
## Technical Specification v0.1

**Status:** Engineering baseline
**Date:** November 7, 2026
**Target:** NEAR Hackathon 2026
**Implementation:** Rust / NEAR SDK 5.x, OutLayer WASI evaluator, TypeScript SDK
**Network:** NEAR testnet
**Parent specification:** LCP PRD v0.2

---

# 1. Engineering Objective

Implement a minimal, reusable NEAR protocol that maintains the health of an ongoing commitment based on time-sensitive evidence and enforces financial consequences according to that health.

The initial implementation must demonstrate:

1. A commitment is created with an immutable policy.
2. An authorized evaluation is requested through OutLayer.
3. A hash-pinned WASM evaluator returns a verdict.
4. The contract accepts the verdict only when it matches the pending request.
5. A compliant observation makes the commitment Healthy.
6. Evidence expiration makes it AtRisk.
7. The grace-period deadline makes it Breached.
8. A Breached commitment cannot authorize a new budget tranche.
9. Fresh compliant evidence can restore Healthy status.
10. A recovered commitment can authorize a future tranche.

**Non-goal:** Building a generic DAO, a complete escrow marketplace, a universal oracle, or a policy compiler.

---

# 2. Architectural Decisions

## 2.1 Single authoritative contract

The MVP uses one NEAR contract for:

- Commitment state.
- Policy storage.
- Evaluation requests.
- Evaluation acceptance.
- Temporal state derivation.
- Challenge handling.
- Native NEAR escrow.
- Tranche authorization.
- Transfer reconciliation.

The WASM evaluator executes off-chain through OutLayer.

This reduces cross-contract coordination complexity during the hackathon.

## 2.2 Three separate authorities

**Evaluation authority**

The pinned evaluator determines whether supplied evidence satisfies the evidence policy.

**State authority**

LCP applies the temporal policy to accepted evaluations and current blockchain time.

**Consequence authority**

LCP authorizes or rejects a financial operation based on the current effective state.

No evaluator verdict directly transfers money.

## 2.3 Immutable policy in v0.1

Each commitment has a policy version and digest.

Version 1 is immutable after activation.

A full amendment engine for all commitment terms is deferred by design. P1 supports v3 service-source-policy amendments only; budget, evaluator, and role terms are founding commitment terms and remain immutable. Changing them would alter financial exposure, evidence authority, or governance identities, so the sponsor should create a new commitment until a separately versioned full-amendment design is reviewed. Every required approver may approve or reject a pending proposal, and rejection leaves the active digest unchanged while releasing the proposal slot. Historical evaluations retain their original policy digest.

## 2.4 Deterministic time

All stored timestamps use unsigned 64-bit **nanoseconds**.

All state transitions use the NEAR blockchain timestamp.

No frontend timestamp, evaluator clock, or server clock may independently determine whether an on-chain consequence is allowed.

## 2.5 One pending evaluation

Only one evaluation request may be pending per commitment.

This avoids conflicting asynchronous results in the first implementation.

Each request has a monotonically increasing identifier.

## 2.6 One budget beneficiary

The MVP supports one sponsor and one budget beneficiary per commitment.

The financial model is intentionally simple.

## 2.7 No automatic catch-up

An unclaimed budget epoch expires when the next epoch begins, except for a single epoch whose potential claim window was reserved when a challenge opened.

Recovery restores eligibility for the current or future epochs, not missed payments. A reserved epoch is an explicit exception for a claim window interrupted by a challenge; it is not general catch-up eligibility.

---

# 3. Protocol State Model

## 3.1 Commitment lifecycle

The stored lifecycle is:

- `Draft`
- `Active`
- `Closed`

The health state is separately derived.

## 3.2 Health states

- `AwaitingEvidence`
- `Healthy`
- `AtRisk`
- `Breached`
- `Closed`

`Recovered` is an event, not a permanent state.

`Challenged` is a dispute condition, not a replacement for health.

## 3.3 State transition table

| Current state | Trigger | Next state | Consequence |
|---|---|---|---|
| AwaitingEvidence | Fresh compliant evaluation | Healthy | May become eligible |
| AwaitingEvidence | Initial deadline reached | AtRisk | Blocked |
| AtRisk | Grace period elapsed | Breached | Blocked |
| Healthy | Evidence TTL elapsed | AtRisk | Blocked |
| Healthy | Accepted noncompliant evaluation | AtRisk | Blocked |
| AtRisk | Fresh compliant evaluation | Healthy | Eligibility restored |
| Breached | Fresh compliant evaluation and recovery allowed | Healthy | Eligibility restored |
| Breached | Fresh compliant evaluation and recovery forbidden | Breached | Blocked |
| Any active state | Valid challenge on governing evaluation | Health unchanged; challenge open | Blocked |
| Any active state | Authorized closure | Closed | No new claims |

## 3.4 Exact boundary semantics

For an accepted compliant observation:

`expires_at = observed_at + ttl`

`breach_at = expires_at + grace`

Then:

- Healthy if `now < expires_at`.
- AtRisk if `expires_at <= now < breach_at`.
- Breached if `now >= breach_at`.

For no accepted evidence:

`initial_deadline = activated_at + initial_window`

The same AtRisk and Breached thresholds apply after the initial deadline.

For an accepted noncompliant evaluation:

- Record `negative_since` when the first unresolved negative evaluation is accepted.
- Enter AtRisk immediately.
- Enter Breached when `now >= negative_since + grace`.

Repeated negative evaluations **must not reset** the grace-period clock.

A new qualifying compliant evaluation clears the unresolved negative condition if recovery is permitted.

All timestamp arithmetic must use checked addition and reject overflow.

---

# 4. Canonical Rust Data Structures

The following is the intended contract-state model for NEAR SDK 5.x.

It is a source-level specification. The final repository must pin exact dependency versions and compile these declarations against its lockfile.

```rust
use near_sdk::{
    borsh::{BorshDeserialize, BorshSerialize},
    store::LookupMap,
    AccountId,
    PanicOnDefault,
};

pub type CommitmentId = u64;
pub type EvaluationId = u64;
pub type ChallengeId = u64;
pub type TransferId = u64;

#[derive(
    BorshDeserialize,
    BorshSerialize,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Debug
)]
#[borsh(crate = "near_sdk::borsh")]
pub enum Lifecycle {
    Draft,
    Active,
    Closed,
}

#[derive(
    BorshDeserialize,
    BorshSerialize,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Debug
)]
#[borsh(crate = "near_sdk::borsh")]
pub enum Health {
    AwaitingEvidence,
    Healthy,
    AtRisk,
    Breached,
    Closed,
}

#[derive(
    BorshDeserialize,
    BorshSerialize,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Debug
)]
#[borsh(crate = "near_sdk::borsh")]
pub enum Verdict {
    Compliant,
    NonCompliant,
}

#[derive(
    BorshDeserialize,
    BorshSerialize,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Debug
)]
#[borsh(crate = "near_sdk::borsh")]
pub enum EvaluationStatus {
    Pending,
    Accepted,
    Rejected,
    Failed,
    TimedOut,
}

#[derive(
    BorshDeserialize,
    BorshSerialize,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Debug
)]
#[borsh(crate = "near_sdk::borsh")]
pub enum ChallengeStatus {
    Open,
    Upheld,
    Invalidated,
    TimedOut,
}

#[derive(
    BorshDeserialize,
    BorshSerialize,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Debug
)]
#[borsh(crate = "near_sdk::borsh")]
pub enum TrancheStatus {
    Unclaimed,
    Pending,
    Paid,
    Failed,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct TemporalPolicy {
    pub initial_window_ns: u64,
    pub evidence_ttl_ns: u64,
    pub grace_ns: u64,
    pub max_source_lag_ns: u64,
    pub challenge_window_ns: u64,
    pub resolution_timeout_ns: u64,
    pub recovery_allowed: bool,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct EvidencePolicy {
    /// Raw Ed25519 public key for v1; typed-key SHA-256 fingerprint for v2.
    pub maintainer_public_key: [u8; 32],
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct EvaluatorPolicy {
    pub outlayer_account: AccountId,
    pub wasm_url: String,
    pub wasm_sha256: [u8; 32],
    pub build_target: String,
    pub max_instructions: u64,
    pub max_memory_mb: u32,
    pub max_execution_seconds: u64,
    pub request_timeout_ns: u64,
    pub execution_deposit_yocto: u128,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct BudgetPolicy {
    pub sponsor: AccountId,
    pub beneficiary: AccountId,
    pub epoch_ns: u64,
    pub max_epochs: u32,
    pub tranche_yocto: u128,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct CommitmentPolicy {
    pub version: u32,
    pub temporal: TemporalPolicy,
    pub evidence: EvidencePolicy,
    pub evaluator: EvaluatorPolicy,
    pub budget: BudgetPolicy,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct GoodObservation {
    pub evaluation_id: EvaluationId,
    pub evidence_hash: [u8; 32],
    pub observed_at_ns: u64,
    pub accepted_at_ns: u64,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct Commitment {
    pub id: CommitmentId,
    pub subject: String,
    pub creator: AccountId,
    pub maintainer: AccountId,
    pub arbiter: AccountId,

    pub lifecycle: Lifecycle,
    pub policy: CommitmentPolicy,
    pub policy_hash: [u8; 32],

    pub activated_at_ns: Option<u64>,

    pub last_good: Option<GoodObservation>,
    pub last_observed_at_ns: Option<u64>,
    pub negative_since_ns: Option<u64>,

    pub pending_evaluation_id: Option<EvaluationId>,
    pub active_challenge_id: Option<ChallengeId>,

    pub breach_latched: bool,

    pub escrow_funded_yocto: u128,
    pub escrow_paid_yocto: u128,
    pub escrow_refunded_yocto: u128,
    pub escrow_pending_yocto: u128,

    pub operations_funded_yocto: u128,
    pub operations_authorized_spend_yocto: u128,
    pub storage_deposit_yocto: u128,

    pub next_evaluation_id: EvaluationId,
    pub challenge_count: u32,
    pub pending_transfer_count: u32,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct EvaluationRequest {
    pub id: EvaluationId,
    pub commitment_id: CommitmentId,
    pub policy_version: u32,
    pub policy_hash: [u8; 32],

    pub input_hash: [u8; 32],
    pub evidence_hash: [u8; 32],
    pub observed_at_ns: u64,

    pub requested_at_ns: u64,
    pub timeout_at_ns: u64,
    /// All-zero placeholder reserves callback storage until a hash is available.
    pub request_transaction_hash: Option<[u8; 32]>,

    pub status: EvaluationStatus,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct EvaluationRecord {
    pub request_id: EvaluationId,
    pub commitment_id: CommitmentId,
    /// All-zero placeholder reserves callback storage; views expose it as absent until set.
    pub request_transaction_hash: Option<[u8; 32]>,
    pub status: EvaluationStatus,
    pub verdict: Option<Verdict>,
    pub reason_codes: Vec<String>,
    pub input_hash: [u8; 32],

    pub evidence_hash: [u8; 32],
    pub observed_at_ns: u64,
    pub accepted_at_ns: Option<u64>,

    pub policy_hash: [u8; 32],
    pub output_hash: Option<[u8; 32]>,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct Challenge {
    pub id: ChallengeId,
    pub commitment_id: CommitmentId,
    pub evaluation_id: EvaluationId,
    pub challenger: AccountId,
    pub reason_hash: [u8; 32],

    pub opened_at_ns: u64,
    pub resolution_deadline_ns: u64,

    pub status: ChallengeStatus,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct Tranche {
    pub commitment_id: CommitmentId,
    pub epoch: u32,
    pub amount_yocto: u128,
    pub status: TrancheStatus,
    pub transfer_id: Option<TransferId>,
}

#[derive(BorshDeserialize, BorshSerialize, Clone, Copy)]
#[borsh(crate = "near_sdk::borsh")]
pub enum TransferKind {
    Tranche,
    Refund,
}

#[derive(BorshDeserialize, BorshSerialize, Clone)]
#[borsh(crate = "near_sdk::borsh")]
pub struct PendingTransfer {
    pub id: TransferId,
    pub commitment_id: CommitmentId,
    pub kind: TransferKind,
    pub epoch: Option<u32>,
    pub recipient: AccountId,
    pub amount_yocto: u128,
}

#[near_sdk::near(contract_state)]
#[derive(PanicOnDefault)]
pub struct Contract {
    pub next_commitment_id: CommitmentId,
    pub next_challenge_id: ChallengeId,
    pub next_transfer_id: TransferId,

    pub commitments: LookupMap<CommitmentId, Commitment>,
    pub evaluation_requests:
        LookupMap<(CommitmentId, EvaluationId), EvaluationRequest>,
    pub evaluation_records:
        LookupMap<(CommitmentId, EvaluationId), EvaluationRecord>,
    pub challenges: LookupMap<ChallengeId, Challenge>,
    pub challenge_by_evaluation: LookupMap<(CommitmentId, EvaluationId), ChallengeId>,
    pub tranches: LookupMap<(CommitmentId, u32), Tranche>,
    pub pending_transfers: LookupMap<TransferId, PendingTransfer>,
}
```

`ChallengeView` additionally exposes optional `completed_at_ns` and `timeout_preserves_evidence`. New challenges reserve fixed-width timestamp and timeout-policy slots in raw contract storage when opened, without changing the persisted `Challenge` or top-level contract state layout. A separate optional epoch slot records the single claim opportunity that may resume after an upheld or timed-out challenge. Older challenges report no preservation marker; the Console keeps their historical timeout semantics rather than rewriting the past.

## 4.1 Storage requirements

- IDs must be unique within their defined scope.
- Stored hashes must be exactly 32 bytes.
- `policy_hash` is SHA-256 of the Borsh serialization of the v1 `CommitmentPolicy`, with fields serialized in the order declared in the canonical Rust model.
- Strings and evidence payloads must have explicit maximum lengths.
- The contract must enforce a maximum number of evaluation records per commitment for the hackathon release.
- Large evidence content must remain off-chain.
- Historical records must not be silently overwritten.
- View methods must use JSON-safe representations for `u64` timestamps and `u128` balances.

The public JSON interface should serialize large integers as decimal strings.

## 4.2 Storage deposits

The implementation must separately account for:

- Contract storage.
- Commitment escrow.
- Evaluation execution expenses.

A fixed commitment storage bond is acceptable only if its amount is derived from measured storage usage and bounded record counts.

The initial implementation measures storage growth when creating and activating a commitment, requires the corresponding storage deposit, records that amount separately from escrow and evaluation funding, and refunds any excess attached deposit. Later state transitions that grow storage must follow the same accounting rule. Storage deposits are not available for budget claims.

Escrow funds must never be used to subsidize unlimited evaluation requests.

---

# 5. Pure Temporal State Function

The core health calculation must be a pure function.

It must not:

- Transfer funds.
- Modify storage.
- Call external contracts.
- Trust a frontend-provided status.
- Require an indexer.

Reference implementation:

```rust
pub fn effective_health(
    commitment: &Commitment,
    now_ns: u64,
) -> Health {
    match commitment.lifecycle {
        Lifecycle::Closed => return Health::Closed,
        Lifecycle::Draft => return Health::AwaitingEvidence,
        Lifecycle::Active => {}
    }

    if commitment.breach_latched {
        return Health::Breached;
    }

    let temporal = &commitment.policy.temporal;

    if let Some(negative_since) = commitment.negative_since_ns {
        let breach_at = negative_since
            .checked_add(temporal.grace_ns)
            .expect("time overflow");

        return if now_ns < breach_at {
            Health::AtRisk
        } else {
            Health::Breached
        };
    }

    if let Some(good) = &commitment.last_good {
        let expires_at = good
            .observed_at_ns
            .checked_add(temporal.evidence_ttl_ns)
            .expect("time overflow");

        let breach_at = expires_at
            .checked_add(temporal.grace_ns)
            .expect("time overflow");

        if now_ns < expires_at {
            Health::Healthy
        } else if now_ns < breach_at {
            Health::AtRisk
        } else {
            Health::Breached
        }
    } else {
        let activated_at = commitment
            .activated_at_ns
            .expect("active commitment has activation time");

        let initial_deadline = activated_at
            .checked_add(temporal.initial_window_ns)
            .expect("time overflow");

        let breach_at = initial_deadline
            .checked_add(temporal.grace_ns)
            .expect("time overflow");

        if now_ns < initial_deadline {
            Health::AwaitingEvidence
        } else if now_ns < breach_at {
            Health::AtRisk
        } else {
            Health::Breached
        }
    }
}
```

## 5.1 Important semantics

A challenge does not change the health calculation.

Instead, an open challenge independently blocks the affected financial consequence.

A failed evaluation does not create a fresh compliant observation.

A negative evaluation sets `negative_since_ns` only if there is no unresolved negative condition.

A qualifying positive evaluation clears `negative_since_ns`.

If recovery is forbidden and the effective state has reached Breached, the contract must latch that breach before processing a new positive verdict.

---

# 6. Evaluation Request Protocol

## 6.1 Request method

Proposed contract method:

`request_evaluation(commitment_id, evidence_payload)`

The caller must be an authorized sponsor or maintainer for the MVP.

Preconditions:

- Commitment is Active.
- No evaluation is already pending.
- Evaluation limit has not been reached.
- Required execution budget is available.
- The evaluator configuration is valid.
- Evidence payload is within the size limit.

The method:

1. Allocates a new evaluation ID.
2. Constructs canonical evaluator input.
3. Hashes the exact input bytes.
4. Stores the pending request.
5. Calls OutLayer.
6. Chains a private callback to the LCP contract.

## 6.2 Evaluator input schema

```json
{
  "schema": "lcp.evaluation.request.v1",
  "commitment_id": "1",
  "evaluation_id": "4",
  "policy_version": 1,
  "policy_hash": "64-character-sha256-hex",
  "evidence_hash": "64-character-sha256-hex",
  "observed_at_ns": "1794090000000000000",
  "subject": "example-maintenance-program",
  "evidence": {
    "type": "signed_maintenance_heartbeat",
    "artifact_hash": "64-character-sha256-hex",
    "maintainer_public_key": "64-character-ed25519-public-key-hex",
    "signature": "encoded-signature",
    "payload": "canonical-signed-message"
  }
}
```

The timestamp above is illustrative.

The maintainer public key is pinned in the immutable evidence policy. The contract must reject a request whose key differs from that value. The evaluator must verify the signed payload and ensure its contents match the supplied commitment, evaluation ID, policy version and digest, observation timestamp, and evidence digest.

The signed payload must not be reusable to refresh another commitment.

The v1 signed heartbeat payload is compact canonical JSON with this field order:

```json
{
  "schema": "lcp.heartbeat.v1",
  "commitment_id": "1",
  "evaluation_id": "4",
  "policy_version": 1,
  "policy_hash": "64-character-sha256-hex",
  "observed_at_ns": "1794090000000000000",
  "subject": "example-maintenance-program",
  "artifact_hash": "64-character-sha256-hex"
}
```

The maintainer signs the exact UTF-8 bytes of this JSON with Ed25519. `evidence_hash` is SHA-256 of those bytes. The outer evidence object contains `type`, `artifact_hash`, `maintainer_public_key`, `signature`, and the payload string, in that order. Hash strings use lowercase hexadecimal; timestamps and IDs use canonical decimal strings. Commitment subjects are limited to printable ASCII so Rust and TypeScript produce the same canonical payload bytes.

### 6.2.1 Version 2 NEP-413 wallet evidence

New commitments use policy version `2` and the `near_nep413` signature scheme. The persisted Borsh policy layout does not change: the existing 32-byte evidence key slot stores `SHA-256(UTF-8("ed25519:<base58 public key>"))`. Policy views expose this fingerprint, not a different key encoding. Version 1 policies and evidence keep their original raw Ed25519 meaning and serialized shape.

The maintainer key is obtained from a NEP-413 wallet `signMessage` response. New evidence keeps the same canonical `lcp.heartbeat.v1` message fields, with `policy_version: 2`, and adds `signature_scheme: "near_nep413"`, `nonce_hex` (32 random bytes as 64 lowercase hex characters), `recipient` (the current LCP contract account ID), and `callback_url` (the app page URL passed to the wallet). The typed `maintainer_public_key` is `ed25519:<base58>`, and `signature` is the wallet's canonical base64 encoding of the 64-byte Ed25519 signature. These optional envelope fields follow `payload` in the canonical evaluator JSON; v1 omits them.

For verification, Borsh-serialize the NEP-413 payload in this order: `message: String`, `nonce: [u8; 32]`, `recipient: String`, `callbackUrl: Some(callback_url)`. Prefix the serialization with the little-endian `u32` tag `2^31 + 413` (`2147484061`), compute SHA-256 over the resulting bytes, then verify the Ed25519 signature over that 32-byte digest. The contract checks the policy fingerprint, typed key, scheme, nonce, and contract recipient; the evaluator performs the cryptographic signature check. The v2 evaluator request also includes `contract_id` after the evidence object so it can confirm the signed recipient. Version 1 evaluator input omits this optional field, preserving its existing canonical bytes.

Wallet integrations use the NEAR connector capability interface rather than wallet-vendor branches. A wallet that does not return a NEP-413 `SignedMessage` cannot complete the v2 evidence flow; existing v1 commitments remain readable and retain their legacy signature rules.

## 6.3 Evaluator output schema

```json
{
  "schema": "lcp.evaluation.verdict.v2",
  "request_transaction_hash": "base58-encoded-NEAR-transaction-hash",
  "commitment_id": "1",
  "evaluation_id": "4",
  "policy_version": 1,
  "policy_hash": "64-character-sha256-hex",
  "input_hash": "64-character-sha256-hex",
  "evidence_hash": "64-character-sha256-hex",
  "observed_at_ns": "1794090000000000000",
  "verdict": "Compliant",
  "reason_codes": ["SIGNATURE_VALID", "ARTIFACT_PRESENT"]
}
```

Allowed verdicts:

- `Compliant`
- `NonCompliant`

Unknown values must be rejected.

## 6.4 Canonical serialization

Use one deterministic serialization function for evaluator inputs.

The contract hashes the exact UTF-8 bytes passed as `input_data`.

Do not calculate a digest from one JSON serialization and send a differently ordered or formatted serialization to OutLayer.

The evaluator must echo the expected identifiers and input digest.

The callback compares these fields against the stored pending request.

The contract reserves storage for each bounded evaluation record before dispatching OutLayer. At most 64 requests are retained per commitment, and callback reason codes are limited to 16 uppercase ASCII codes of at most 64 bytes each. Timeout, failure, and rejected results release the pending lock without changing evidence freshness.

Challenge history and budget programs are also bounded to 64 records/epochs per commitment. The contract keeps a monotonic observation timestamp after a challenge invalidates an observation, so an older timestamp cannot be reused to restore eligibility.

---

# 7. OutLayer Integration Contract

## 7.1 Documented endpoint

**Receiver:** `outlayer.testnet`

**Method:** `request_execution`

The v0.1 policy accepts `outlayer.testnet` or `outlayer.near`, `wasm32-wasip1` or `wasm32-wasip2`, and documented limits up to 500 billion instructions, 4096 MB, and 180 seconds. The hackathon deployment uses the testnet receiver.

The documented interface accepts:

- `source`
- `resource_limits`
- `input_data`
- `response_format`
- Optional payment and secret parameters.

The MVP will use `WasmUrl` to pin the exact evaluator binary.

## 7.2 Proposed request payload

```json
{
  "source": {
    "WasmUrl": {
      "url": "https://test.fastfs.io/.../evaluator.wasm",
      "hash": "64-character-sha256-hex",
      "build_target": "wasm32-wasip2"
    }
  },
  "resource_limits": {
    "max_instructions": 1000000000,
    "max_memory_mb": 128,
    "max_execution_seconds": 30
  },
  "input_data": "{\"schema\":\"lcp.evaluation.request.v1\",...}",
  "response_format": "Json",
  "payer_account_id": "sponsor.testnet"
}
```

The URL and hash are deployment configuration values, not placeholders to ship.

The actual build target must match the compiled WASM.

The updated LCP request builder sets `payer_account_id` to the configured sponsor, who funds evaluator operations. [OutLayer documents](https://app.outlayer.ai/docs/near-integration) that unused resources are refunded to this account. Existing deployed contracts omit this optional field and therefore use OutLayer's default payer (the LCP contract sender) until upgraded. The LCP ledger still reserves the full configured deposit for each request. A missing or failed result is recorded as `Failed`, never converted into a health verdict, and does not refresh prior evidence. The callback records the returned output digest (including JSON `null`) for diagnosis.

In November 2026 testnet traces, 11 of 13 dispatched requests failed at OutLayer's `resolve_execution` step with `Execution request not found`; the worker executions took 453–648 ms. LCP received JSON `null`, recorded `MISSING_OUTLAYER_RESULT`, cleared the pending lock, and preserved prior evidence. The public error localizes the incident to OutLayer settlement/request state, but does not reveal why the request was absent.

## 7.3 NEAR promise sequence

Conceptually:

```text
LCP.request_evaluation()
    |
    | save Pending request
    |
    v
outlayer.testnet.request_execution()
    |
    | TEE executes pinned WASM
    |
    v
LCP.on_outlayer_result()
    |
    | validate result
    |
    +--> Accepted -> update evidence state
    |
    +--> Failed/Rejected -> preserve old evidence age
```

The implementation should follow OutLayer's documented NEAR promise pattern.

LCP does not need to implement a separate low-level yield/resume transport when the OutLayer contract already provides the required integration.

## 7.4 Private callback

Proposed signature:

`on_outlayer_result(commitment_id, evaluation_id)`

Requirements:

- Must be callable only through the expected private callback path.
- Must inspect the result of the preceding OutLayer promise.
- Must locate the exact pending request.
- Must reject obsolete or mismatched requests.
- Must not accept the same result twice.
- Must not panic after partially mutating settlement-related state.
- Must record a failed result without extending evidence freshness.

## 7.5 Callback validation order

1. Verify the callback's private invocation context.
2. Load the commitment and request.
3. Confirm the request is Pending.
4. Confirm it is the commitment's current pending request.
5. Confirm policy version and digest.
6. Confirm the preceding promise succeeded.
7. Parse the actual OutLayer return encoding.
8. Decode the originating transaction hash supplied by the evaluator.
9. Validate the verdict schema.
10. Confirm commitment and evaluation IDs.
11. Confirm input and evidence digests.
12. Validate source timestamp.
13. Apply the verdict and store the transaction hash.
14. Clear pending request.
15. Emit the appropriate event.

**Integration note:** The exact byte encoding returned by OutLayer's `Json` response format must be confirmed with a real testnet execution. Do not assume raw stdout bytes and NEAR's serialized return value are identical.

## 7.6 Source freshness validation

For a compliant verdict, require:

- `observed_at <= current_block_time`
- `current_block_time - observed_at <= max_source_lag`
- `current_block_time < observed_at + evidence_ttl`
- `observed_at` is newer than the previous accepted evaluation observation.
- The evidence hash matches the pending request.

The evaluator is responsible for checking source provenance.

The contract is responsible for checking temporal eligibility and request binding.

## 7.7 Evaluation timeout

Each request has a timeout.

A failed or timed-out request:

- Becomes Failed or TimedOut.
- Releases the commitment's pending-request lock.
- Does not update `last_good`.
- Does not reset `negative_since`.
- Does not extend the freshness deadline.

A late result from an expired request must be rejected.

## 7.8 Attestation verification

OutLayer's execution produces a TEE attestation that can be inspected independently.

The protocol's on-chain acceptance relies on the documented OutLayer contract and execution path; LCP does not independently verify a complete Intel TDX quote in v0.1.

The evaluator reads OutLayer's `NEAR_TRANSACTION_HASH` execution environment value and returns it in its verdict. The LCP callback validates and stores it as lowercase hexadecimal, and the SDK exposes it for a NEAR Explorer link plus `outlayer-verify tx <base58-hash> --network <network>`. Pending or failed executions without a valid verdict have no transaction hash.

OutLayer documents transaction-hash lookup for on-chain executions and recovery of request and response data from NEAR. Live integration must still confirm that this LCP promise chain resolves to the expected job and attestation.

An optional indexer may store that mapping, but it must not become the authority for health or settlement.

---

# 8. Evaluator WASM Specification

## 8.1 Runtime

Rust compiled for the OutLayer-supported WASI target.

The executable:

- Reads one JSON request from stdin.
- Validates its schema.
- Validates the evidence signature.
- Checks the evidence's commitment binding.
- Checks the artifact digest format.
- Produces one JSON verdict on stdout.
- Uses a nonzero exit code for malformed requests or internal errors.

## 8.2 Demonstration evidence

The initial evaluator validates a signed maintenance heartbeat.

This proves that a designated maintainer submitted a properly bound statement.

It does not independently prove service uptime.

The LCP Console must describe this as a controlled evidence source.

## 8.3 Evaluator determinism

For identical inputs, the evaluator should produce identical verdicts.

The evaluator should not use:

- Random values.
- Unpinned external dependencies.
- Mutable external API responses.
- Its own wall-clock time as the authoritative freshness clock.

The contract determines freshness using NEAR time.

## 8.4 Evaluator security tests

- Valid signature.
- Invalid signature.
- Wrong commitment ID.
- Wrong policy hash.
- Modified artifact digest.
- Replayed payload with wrong evaluation ID.
- Missing required fields.
- Unsupported schema version.
- Malformed JSON.
- Oversized input.

---

# 9. Financial Model

## 9.1 Escrow allocation

A commitment specifies:

- `max_epochs`
- `epoch_ns`
- `tranche_yocto`
- `beneficiary`

Required escrow:

`required_escrow = max_epochs × tranche_yocto`

For the v0.1 contract, `max_epochs` is limited to 64 so tranche history remains bounded.

Use checked multiplication.

The sponsor must fund the required amount before activation.

## 9.2 Epoch calculation

For an active commitment:

`elapsed = now - activated_at`

`current_epoch = floor(elapsed / epoch_ns)`

The epoch is eligible only if:

`current_epoch < max_epochs`

Only the current epoch can be claimed, except for a previously reserved epoch whose claim window was paused by an upheld or timed-out challenge.

Earlier unclaimed epochs are not retroactively payable. A challenge reserves an epoch only if the commitment is Active and Healthy, its accepted compliant evidence has a positive policy-valid claim interval, that epoch is unpaid, and escrow already covers its tranche. The normal claim window begins after both the challenge window and epoch start, and ends at the earlier of evidence expiry or epoch end. If the challenge resolves after that window begins, the remaining duration resumes after resolution. An invalidated challenge removes the reservation; a later substantive accepted evaluation supersedes it.

## 9.3 Claim authorization

A tranche claim is permitted only when:

- Lifecycle is Active.
- Current effective health is Healthy.
- No blocking challenge is open.
- The governing compliant evaluation's challenge window has elapsed.
- The current epoch is within the funded program, or the contract has a live reserved claim window for the epoch.
- The epoch has not been paid or placed in pending settlement.
- The commitment has sufficient unallocated escrow.
- The intended beneficiary matches the immutable budget policy.

## 9.4 Escrow accounting

Maintain four amounts:

- `escrow_funded`
- `escrow_paid`
- `escrow_refunded`
- `escrow_pending`

Define:

`escrow_free = funded - paid - refunded - pending`

`escrow_liability = funded - paid - refunded`

Invariant:

`funded = paid + refunded + pending + free`

All arithmetic must be checked.

## 9.5 Transfer lifecycle

```text
Unclaimed
    |
    | valid claim
    v
Pending
    |
    +---- transfer succeeds ----> Paid
    |
    +---- transfer fails -------> Failed
```

When initiating a transfer:

- Mark the tranche Pending.
- Allocate a unique transfer ID.
- Increase `escrow_pending`.
- Persist the pending transfer.
- Initiate the NEAR transfer.
- Attach a private callback.

On successful callback:

- Decrease `escrow_pending`.
- Increase `escrow_paid`.
- Mark tranche Paid.
- Remove the pending transfer.

On failed callback:

- Decrease `escrow_pending`.
- Mark tranche Failed.
- Remove the pending transfer.
- Permit a retry only while the same epoch remains eligible.

## 9.6 Asynchronous balance accounting

While a NEAR transfer is in flight, the contract's account balance may already reflect the outgoing amount before the callback reconciles its accounting.

Solvency checks must account for pending outgoing transfers.

The implementation must not naïvely compare the current account balance with the full escrow liability without considering in-flight transfers.

## 9.7 Evaluation funding

OutLayer execution fees must be funded separately from commitment escrow.

The MVP will use a bounded operations budget:

- Sponsor deposits an operations allowance.
- Each authorized evaluation reserves a maximum execution fee.
- Evaluation count and concurrency are limited.
- The contract never intentionally spends escrow allocations on evaluator execution.

The updated LCP request builder sets OutLayer `payer_account_id` to the commitment sponsor, so unused-resource refunds are routed directly to the sponsor when OutLayer settles the execution. Testnet acceptance passed on commitment `38` after the reproducible core upgrade recorded in `TESTNET-E2E-STATUS.md`. The commitment ledger conservatively reserves the full configured deposit per attempt and does not automatically recredit it; a sponsor may need to add operations funds again even after receiving an OutLayer refund. After closure, `refund_unused_operations` lets only the configured sponsor recover the unreserved operations balance held by LCP. It requires pending evaluations, challenges, and transfers to settle first; a private transfer callback removes the pending record on success or restores the balance after failure. The method takes a measured storage bond and returns any excess attached deposit. Commitment `38` verified the sponsor-directed OutLayer refund, the `refund_unused_operations` callback, and successful excess-storage-refund callbacks; finalized receipts are linked in `TESTNET-E2E-STATUS.md`.

## 9.8 Storage solvency

The contract must maintain sufficient balance for NEAR storage requirements and a safety reserve.

Before initiating an external payment, verify that the outgoing amount does not compromise reserved escrow or required storage backing.

The exact solvency formula must be tested using actual NEAR runtime balances, including pending transfers and execution refunds.

## 9.9 Multi-asset settlement (P2 implementation in progress)

The deployed v0.1 accounting model and its `*_yocto` fields remain native-NEAR-only. The current reproducible testnet core includes a generic NEP-141 settlement backend, initially for Circle USDC, while preserving the native path for existing commitments. The code is deployed but has not passed independent invariant review or live USDC acceptance. Do not interpret stored yoctoNEAR fields as fungible-token atomic units or change existing Borsh layouts without an explicit versioned migration design.

Each new commitment binds one asset kind, the NEP-141 contract account when applicable, and a raw integer tranche amount into its immutable policy digest. The implementation uses versioned sidecars for asset and token-unit accounting, `ft_transfer_call` with a validating `ft_on_transfer` receiver for funding, and `ft_transfer` with persisted pending state and private callbacks for claims and refunds. The sponsor's `ft_transfer_call` and outgoing NEP-141 transfers each require a separate 1 yoctoNEAR security deposit. Both paths must preserve the same solvency, replay, callback-idempotency, failure-recovery, and no-double-payment invariants. NEAR remains required for execution gas, storage deposits, token storage registration, and OutLayer operations. Reserve outgoing-transfer deposits from the caller's NEAR attachment separately from storage growth and refund any remaining excess. The deployed code remains unaccepted until independent review and focused live testnet validation are complete.

The initial USDC catalog entries are the Circle NEAR testnet account `3e2210e1184b45b64c8a434c0a7e7b23cc04ea7eb7a6c3c32520d03d4afcb8af` and mainnet account `17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1`, both with six decimals. Verify the addresses at release time against [Circle's network list](https://www.circle.com/multi-chain-usdc). NEP-141 transfers use integer amounts, and NEP-145 token registration uses NEAR-denominated storage deposits; never use floating-point arithmetic or assume recipients are registered.

The NEAR-only bounded payout adapter rejects USDC commitments until an asset-matched adapter is designed. Contract views/events, SDK types, and Console surfaces expose explicit asset identifiers and raw amounts while retaining compatibility for existing NEAR records. The event indexer stores complete event JSON, so no schema migration is required for these additional fields. Focused contract and SDK tests passed on 2026-11-13; independent invariant review and live USDC acceptance remain open. The reproducible testnet deployment is recorded in `TESTNET-E2E-STATUS.md`; see [P2-ASSET-ARCHITECTURE.md](P2-ASSET-ARCHITECTURE.md) for remaining gates.

---

# 10. Challenges

## 10.1 Opening a challenge

A named sponsor or maintainer may challenge the latest accepted compliant evaluation within its challenge window.

The challenge must reference a specific evaluation ID.

A valid challenge immediately blocks tranche claims.

## 10.2 Resolution

The designated arbiter may:

- Uphold the evaluation.
- Invalidate the evaluation.

If upheld:

- Close the challenge.
- Preserve the evaluation.
- Recompute current health before any later consequence.

- Resume any claim window paused by the challenge, preserving only its unused duration.

If invalidated:

- Close the challenge.
- Invalidate the governing evidence for eligibility.
- Enter AtRisk, using the resolution time as the negative-condition anchor.
- Require fresh compliant evidence for recovery.

- Remove any epoch claim reservation made when this challenge opened.

## 10.3 Timeout

A challenge has a finite resolution deadline.

If unresolved:

- The challenge is marked TimedOut.
- The challenge is dismissed, not decided against either party.
- The accepted evidence remains in force and its time-derived health continues to advance normally.
- Resume any claim window reserved at challenge opening, preserving its unused duration after timeout is recorded.
- A challenge opened before this behavior was deployed retains its prior outcome; the contract cannot reconstruct or restore an old cleared observation.

## 10.4 Arbiter independence

New commitments require an arbiter distinct from the maintainer, sponsor, and beneficiary. This prevents an interested party from both challenging and adjudicating the evidence. Existing commitment roles are immutable, so the Console warns when an old commitment has overlap and the contract rejects a challenge sent by an account that is also its arbiter. That runtime guard cannot change who resolves an already-open challenge.

## 10.5 Challenge-window boundary

A claim cannot execute before the applicable challenge window ends.

The policy validator must require `max_source_lag_ns + challenge_window_ns < evidence_ttl_ns`, so an observation at the maximum allowed source lag can remain Healthy through the challenge window.

---

# 11. Public Contract API

## 11.1 Mutating methods

| Method | Caller | Effect |
|---|---|---|
| `create_commitment` | Creator | Creates Draft |
| `fund_commitment` | Sponsor | Deposits native NEAR escrow; NEP-141 funding is initiated with `ft_transfer_call` |
| `ft_on_transfer` | Approved NEP-141 token contract | Validates token funding, accepts only the remaining budget, and returns unused units to the resolver |
| `fund_operations` | Sponsor | Deposits evaluation budget |
| `activate_commitment` | Authorized participant | Activates funded commitment |
| `request_evaluation` | Sponsor or maintainer | Starts OutLayer execution |
| `on_outlayer_result` | Private callback | Accepts or rejects result |
| `expire_evaluation` | Anyone | Clears timed-out request |
| `challenge_evaluation` | Authorized party | Opens challenge |
| `resolve_challenge` | Arbiter | Applies challenge decision |
| `expire_challenge` | Anyone | Applies timeout fallback |
| `propose_service_policy_amendment` | Affected party | Proposes a future v3 service-policy change with required approvals |
| `approve_service_policy_amendment` | Required approver | Records approval; may activate when all conditions are met |
| `reject_service_policy_amendment` | Required approver | Rejects a pending proposal and releases its slot without changing active policy |
| `cancel_service_policy_amendment` | Proposer | Cancels a pending proposal |
| `expire_service_policy_amendment` | Anyone after expiry | Records expiry and releases the proposal slot |
| `activate_service_policy_amendment` | Anyone after approval/effective time | Activates the approved v3 service policy |
| `claim_tranche` | Beneficiary | Initiates eligible payment |
| `on_tranche_transfer` | Private callback | Reconciles transfer |
| `on_refund_transfer` | Private callback | Reconciles residual escrow refund |
| `create_bounded_payout_authority_grant` | Sponsor or beneficiary | Grants a named adapter limited authority over its own pool and a fixed recipient |
| `execute_authority_grant` | Grantor or named adapter | Reserves the nonce, epoch, and cumulative allowance while calling the adapter |
| `on_authority_grant_action_settled` | Private callback | Keeps the allowance only on a `true` adapter result; restores its prior values on call failure or `false` |
| `revoke_authority_grant` | Grantor | Revokes a bounded adapter grant |
| `close_commitment` | Creator, maintainer, arbiter, sponsor, or beneficiary | Closes after pending work settles; non-beneficiary callers cannot close over an eligible tranche. The beneficiary may close voluntarily and forfeit it. |
| `refund_remaining` | Sponsor | Refunds eligible residual escrow |

## 11.2 View methods

| Method | Output |
|---|---|
| `get_commitment` | Commitment summary |
| `get_policy` | Current immutable policy |
| `get_effective_health` | Current time-derived health |
| `get_latest_evaluation` | Most recent accepted evaluation |
| `get_evaluation` | Specific evaluation |
| `get_challenge` | Challenge status and optional exact completion timestamp |
| `get_current_epoch` | Current budget epoch |
| `can_claim_tranche` | Eligibility, blocking reason, current and claimable epochs, and whether a challenge-paused window resumed |
| `supports_service_policy_amendment_rejection` | Whether the core supports required-approver rejection |
| `get_escrow_status` | Funding and settlement accounting |
| `get_bounded_payout_authority_grant` | Grant settings, cumulative allowance, and pending settlement status |

## 11.3 API conventions

- Use decimal strings for JSON-exposed large integers.
- Use stable enum names.
- Include schema versions in complex payloads.
- Return structured errors where practical.
- Avoid unbounded collection reads.
- Do not expose privileged callbacks as normal user actions.
- Adapter `execute_authorized_action` implementations return JSON `true` only after the authorized action settles successfully and `false` only when it had no effect. LCP reserves the grant's nonce, epoch, and cumulative allowance while pending, then restores the previous values on call failure or `false`; adapters must reconcile any failed payout before returning `false`.

---

# 12. First Test Suite

The first milestone is not a frontend.

It is a passing state-machine test suite.

## 12.1 Temporal unit tests

| Test | Expected |
|---|---|
| `healthy_before_ttl` | Healthy |
| `at_risk_exactly_at_ttl` | AtRisk |
| `breached_exactly_at_grace_end` | Breached |
| `no_evidence_before_initial_deadline` | AwaitingEvidence |
| `no_evidence_after_initial_deadline` | AtRisk |
| `no_evidence_after_initial_grace` | Breached |
| `negative_verdict_immediate_risk` | AtRisk |
| `repeated_negative_does_not_extend_grace` | Original breach deadline preserved |
| `fresh_positive_recovers` | Healthy |
| `stale_positive_does_not_recover` | Remains non-Healthy |
| `future_observation_rejected` | Rejected |
| `older_observation_rejected` | Rejected |
| `recovery_disabled_latches_breach` | Breached |
| `closed_never_recovers` | Closed |
| `timestamp_overflow_rejected` | Rejected |

## 12.2 Evaluation security tests

| Test | Expected |
|---|---|
| `unauthorized_requester` | Rejected |
| `duplicate_pending_request` | Rejected |
| `wrong_commitment_in_callback` | Rejected |
| `wrong_request_id` | Rejected |
| `wrong_policy_hash` | Rejected |
| `wrong_input_hash` | Rejected |
| `wrong_evidence_hash` | Rejected |
| `replayed_callback` | Rejected |
| `expired_request_callback` | Rejected |
| `failed_outlayer_promise` | No freshness extension |
| `malformed_verdict` | Rejected |
| `unauthorized_direct_callback` | Rejected |

## 12.3 Financial tests

| Test | Expected |
|---|---|
| `claim_when_healthy` | Allowed after challenge window |
| `claim_when_at_risk` | Rejected |
| `claim_when_breached` | Rejected |
| `claim_during_challenge` | Rejected |
| `claim_before_challenge_window_end` | Rejected |
| `claim_twice_same_epoch` | Rejected |
| `claim_missed_prior_epoch` | Rejected |
| `claim_beyond_max_epochs` | Rejected |
| `claim_insufficient_escrow` | Rejected |
| `failed_transfer_restores_allocation` | Correct accounting |
| `successful_transfer_marks_paid` | Correct accounting |
| `duplicate_transfer_callback` | No double accounting |
| `escrow_never_funds_evaluation` | Escrow remains reserved |
| `refund_does_not_exceed_residual` | Correct accounting |

## 12.4 Challenge tests

- Unauthorized challenger rejected.
- Challenge outside window rejected.
- Challenge on wrong evaluation rejected.
- Concurrent challenge rejected.
- Unauthorized arbiter rejected.
- Uphold preserves valid evidence.
- Invalidation removes financial eligibility.
- Timeout dismisses the challenge, preserves accepted evidence, and resumes a reserved claim window.
- Invalidation does not resume its reserved claim window.
- New commitments reject an arbiter who is also maintainer, sponsor, or beneficiary.
- Non-beneficiaries cannot close over an eligible tranche; the beneficiary can claim or explicitly forfeit it by closing.
- Resolution does not authorize an expired evaluation.

## 12.5 Test execution layers

**Unit tests**

Pure temporal and policy logic.

**Contract integration tests**

NEAR storage, access control, promises, and transfer callbacks.

**OutLayer integration test**

Real testnet execution with pinned WASM.

**End-to-end test**

Browser and wallet flow for Healthy → Breached → Recovered.

---

# 13. Repository Architecture

```text
repository-root/
├── .github/
│   ├── dependabot.yml
│   └── workflows/
├── apps/
│   └── console/
│       ├── app/
│       ├── components/
│       └── public/
├── contracts/
│   ├── bounded-payout-adapter/src/
│   └── lcp-core/src/
├── evaluators/
│   ├── maintenance-heartbeat/src/
│   ├── maintenance-heartbeat/tests/
│   └── service-availability/
│       ├── src/
│       ├── test/
│       └── probe.mjs
├── packages/
│   └── sdk/
│       ├── src/
│       └── test/
├── services/
│   ├── event-indexer/
│   │   ├── migrations/
│   │   ├── src/
│   │   └── test/
│   └── reviewer-access/
│       ├── acceptance/
│       ├── migrations/
│       ├── src/
│       └── test/
├── scripts/
├── wrangler.jsonc
├── Cargo.toml
├── Cargo.lock
├── package.json
├── package-lock.json
├── rust-toolchain.toml
├── README.md
├── LICENSE
├── SECURITY.md
├── AGENTS.md
├── TODO.md
├── TESTING.md
├── CONSOLE-GUIDE.md
├── TESTNET-E2E-STATUS.md
├── P1-ARCHITECTURE.md
├── P2-ASSET-ARCHITECTURE.md
├── Living_Commitments_Protocol_[LCP]-PRD.md
└── Living Commitments Protocol - Technical Specification.md
```

## 13.1 Package responsibilities

**`lcp-core`**

All authoritative state and settlement logic.

**`maintenance-heartbeat`**

Minimal hash-pinned OutLayer evaluator.

**`sdk`**

Typed calls, views, and event parsing.

**`schemas`**

Canonical JSON definitions shared across contract tooling, evaluator, and frontend.

**`console`**

A thin interface around protocol functions.

---

# 14. Development Sequence

**Repository status (updated 2026-11-15):** The repository is public and the production Console is live at `https://lcp.gama.works`; production and preview report source revision `f4c4fccf5f6d0a2d268425e9722eaeea2fd49bed`. P0 testnet acceptance, including the reproducible core upgrade, sponsor-directed OutLayer refunds, unused-operations recovery, challenge recovery/claim-window behavior, and successful excess-storage refunds, is recorded in `TESTNET-E2E-STATUS.md`. P1 includes a completed two-operator inbox pilot, consent-amendment and adapter testnet flows, and owner-approved reviewer-access acceptance for the current phase. The optional event indexer is degraded by source rate limiting; contract state remains authoritative and archive history is hidden while the indexer is unhealthy. Reviewer exact-preview fault injection, independent provider validation, and fresh follow-up review are mainnet-readiness work. The reproducible core containing P2 NEP-141/USDC support is deployed to testnet; independent invariant review and live USDC acceptance remain open. The Console displays OutLayer record/hash checks; standalone `outlayer-verify` is still required to verify the TEE quote.

## Milestone A — Pure engine

Implement:

- Rust models.
- Policy validation.
- `effective_health`.
- Temporal unit tests.

**Definition of done:** Every temporal boundary test passes.

## Milestone B — NEAR state

Implement:

- Contract initialization.
- Commitment creation.
- Funding.
- Activation.
- View methods.

**Definition of done:** A funded commitment activates on testnet.

## Milestone C — OutLayer

Implement:

- Evaluator WASM.
- Published evaluator hash.
- Request serialization.
- OutLayer promise call.
- Private callback.
- Result validation.

**Definition of done:** A real OutLayer verdict changes the commitment's evidence state.

## Milestone D — Consequences

The source implements epoch calculation, health-gated claims, escrow accounting, transfer callbacks, and residual escrow refunds after closure. Testnet confirms breached claims are rejected, a healthy tranche pays a distinct beneficiary, a failed transfer restores eligibility and can be retried, and unused escrow refunds reconcile after closure. Broader stress testing across repeated retries remains outside the completed path.

Implement:

- Epoch calculation.
- Health-gated claims.
- Escrow accounting.
- Transfer callbacks.
- Refund path.

**Definition of done:** A valid tranche succeeds and an invalid tranche fails on testnet.

## Milestone E — Recovery and challenge

The source covers positive-evidence recovery, challenge opening/resolution, arbiter timeout, and invalidation of challenged evidence. On the upgraded testnet contract, commitment `29` accepted evaluation `#1`; challenge `#5` timed out and preserved that evidence. The sponsor then closed the commitment before the tranche became eligible, so the test did not exercise non-beneficiary close protection over an eligible tranche. The resumed duration of a reserved claim window also remains to be verified. Earlier commitments retain their historical timeout outcomes, which may have invalidated evidence. Testnet also confirms recovery from `Breached` to `Healthy` and live upheld and invalidated arbiter outcomes. Deterministic tests cover exact initial-evidence, freshness, grace, challenge-window, and timeout boundaries; commitment `21` also crossed its initial-evidence and grace boundaries at finalized NEAR times.

Implement:

- Negative evidence handling.
- Recovery.
- Challenge opening.
- Resolution.
- Timeout fallback.

**Definition of done:** A commitment breaches, blocks payment, recovers, and permits a future payment.

## Milestone F — Public LCP Console

Implement:

- Wallet connection.
- Commitment detail.
- Evidence submission.
- Health timeline.
- Tranche claim.
- OutLayer attestation link.

**Definition of done:** The complete lifecycle is reproducible without CLI intervention.

The user's Firefox validation covered the lifecycle across multiple fixtures: commitment `24` for NEP-413 creation/evaluation/recovery/closure/refund, an isolated fixture for failed-transfer retry, and commitment `19` for successful payout plus closure/refund. The Console preview's wallet connection, NEAR reads, and OutLayer report lookup also passed. Commitment `24` had no claimable tranche because its funded epochs ended; commitment `19` demonstrates payout.

---

# 15. Security Review Checklist

### Account-level upgrade authority

Neither the LCP core nor the bounded payout adapter has an owner, key-management, migration, or self-upgrade method. However, a NEAR account `FullAccess` key can deploy replacement code, so a value-holding contract account that retains such a key is still upgradeable. The v1 mainnet policy is immutable deployment: independently audit and reproducibly build the release, deploy and verify code and initialization, then remove every access key from the core and each funded adapter account and verify the finalized key lists are empty. Testnet accounts remain upgradeable during development. V1 has no emergency upgrade path; future releases use new accounts, and existing commitments remain on the old contract without automatic migration. See [TESTING.md](TESTING.md) for the reproducible build and release gate.

Before deployment, verify:

- Every external callback is appropriately restricted.
- Every evaluation is bound to the correct request.
- Every evaluation uses the active policy version.
- Every accepted observation satisfies source freshness limits.
- Negative evaluations cannot repeatedly extend grace.
- Recovery cannot bypass a permanent breach.
- Challenge windows cannot be bypassed.
- No payment relies only on a stored Healthy label.
- No tranche can be settled twice.
- Failed transfers do not corrupt escrow accounting.
- OutLayer execution fees cannot consume reserved escrow.
- Storage requirements remain funded.
- All financial arithmetic is checked.
- No administrator can withdraw escrow arbitrarily.
- The deployed WASM hash matches the published source build.
- The published source build is reproducible with the NEP-330 metadata and pinned image digest in both contract manifests.
- Each mainnet LCP or funded adapter account has an empty finalized access-key list after code and initialization verification.
- No mainnet release process later adds an access key or deploys replacement code to a v1 account.
- The evaluator's exact input/output can be independently inspected.
- The trust model is documented accurately.

---

# 16. Open Integration Checks

These are the remaining implementation-level unknowns, not unresolved product strategy.

**OUT-001 — Callback encoding — RESOLVED (2026-11-08)**

The live testnet callback decoded and accepted the `response_format: Json` verdict.

**OUT-002 — Execution identity — RESOLVED (2026-11-08)**

The callback stored the originating request transaction hash. `outlayer-verify tx` recovered that transaction's request and response and reported `PROVEN`; see `TESTNET-E2E-STATUS.md`.

**OUT-003 — Execution fee behavior — TESTNET CHARGES MEASURED; RESIDUAL ACCOUNTING LIMITATION REMAINS**

Finalized receipts show the configured `0.01 NEAR` OutLayer deposit on commitment `19` was charged `0.0010706002 NEAR` and refunded `0.0089293998 NEAR` to the contract. A JSON `null` result on commitment `5` charged `0.001 NEAR` and refunded `0.009 NEAR`; a one-yocto promise failure produced no OutLayer refund. LCP conservatively records each full configured deposit as authorized spend, so returned funds are not recredited to that commitment or refunded to its sponsor on close. This matches the documented v0.1 limitation, but production accounting needs a correlated refund/reconciliation path.

**OUT-004 — Promise gas — TESTNET SAMPLE HEADROOM MEASURED**

Across accepted, JSON-null, promise-failure, and timeout receipts, the 20 Tgas LCP callback used at most `2.889554002453 Tgas` (85.55% unused in the sampled maximum). The configured 100 Tgas OutLayer request used at most `4.340434640545 Tgas` in these samples. Maximum-size output and stress-load measurements remain open; these samples do not establish production gas limits.

**OUT-005 — Timeout behavior**

An intentionally mismatched evaluator digest produced JSON `null` under the initial callback and was recorded as `Rejected / MALFORMED_VERDICT`. The updated callback was then verified live: JSON `null` was recorded as `Failed / MISSING_OUTLAYER_RESULT`, retaining its output hash. A second request remained pending past its deadline and later finalized as `TimedOut / OUTLAYER_TIMEOUT`. An underfunded OutLayer execution produced a genuine promise failure and was recorded as `Failed / OUTLAYER_EXECUTION_FAILED`.

**NEAR-001 — Storage reserve — TESTNET HISTORY AND CHALLENGE TIMESTAMP SLOT MEASURED**

Finalized views at block `276853449` reported storage bonds of `0.02738 NEAR` for commitment `8` (one evaluation and challenge), `0.04377 NEAR` for commitment `9` (two evaluations and challenge), `0.0286 NEAR` for closed commitment `19` (one evaluation and payout/refund), and `0.00869 NEAR` for commitment `21` (no evaluation). The updated contract is deployed in [transaction `6md8rayhN3WmiMEP8dGgUyVYUowkBciovGr2Kppdx9cF`](https://testnet.nearblocks.io/txns/6md8rayhN3WmiMEP8dGgUyVYUowkBciovGr2Kppdx9cF), and the two-evaluation/one-challenge recovery fixture `22` reports a total storage deposit of `0.04432 NEAR`. That total covers all retained commitment data, not only the timestamp slot. The contract measures storage growth when each challenge opens, and local tests confirm the reserved completion slot is overwritten without further storage growth. Pre-upgrade challenges return `completed_at_ns: null` because their completion time was not stored.

**NEAR-002 — Transfer accounting — FAILED-TRANSFER RECOVERY VERIFIED (2026-11-08)**

Successful beneficiary payment and sponsor refund reconciled through asynchronous callbacks on testnet. A feature-gated isolated fixture also verified failed-transfer recovery, restored claim eligibility, successful retry, and duplicate-callback idempotency. Receipts are in `TESTNET-E2E-STATUS.md`; broader stress testing across repeated retries remains outside the completed path.

**NEAR-003 — Final SDK compatibility — RESOLVED (2026-11-08)**

NEAR SDK, Rust toolchain, WASI target, and dependency lockfiles are pinned; the deployed contract and evaluator executed successfully on testnet.

No production-readiness claim may be made until these checks pass.

---

# 17. Immediate Engineering Tasks

**Task 009 — Validate the financial consequence on testnet — CORE PATH VERIFIED**

The breached-claim rejection, healthy distinct-beneficiary payout/callback, closure, sponsor refund, and isolated failed-transfer recovery/retry all succeeded. Receipts are in `TESTNET-E2E-STATUS.md`.

**Task 010 — Complete breach, recovery, and updated challenge validation — CORE PATH VERIFIED; CLAIM-WINDOW EDGE CASES OPEN**

Evidence expiry, breached-claim rejection, fresh-evidence recovery, and upheld/invalidated arbiter outcomes were exercised on testnet. Commitment `29` confirmed that a timed-out challenge preserves accepted evidence, but its sponsor closed before eligibility. Commitment `35` later passed the fresh role-separation, eligible-tranche close-guard, and timeout scenario per user confirmation; finalized reads show it Healthy with accepted evaluation `#4` and a TimedOut challenge that preserves evidence. Commitment `36` confirms evaluation `#3` was explicitly invalidated and leaves the commitment AtRisk. Receipt tracing maps `35/#1–#3` and `36/#1–#2, #4–#9` to OutLayer JSON `null` results; all use the same pinned WASI P1 evaluator, while `35/#4` and `36/#3` completed. OutLayer's public jobs API reports 11 of the 13 dispatched requests failed when submitting `resolve_execution`, each rejected by the OutLayer contract with `Execution request not found`; those executions ran for 453–648 ms across two executor IDs. A representative failed job has no attestation record. Running captured failed inputs through the current native evaluator produces a compliant verdict, so invalid heartbeat evidence is not indicated. This localizes the observed failure to OutLayer's resolution/request state, not LCP's callback timeout or evaluator runtime; why OutLayer could not find the request remains unknown from public records. Successful fresh-evidence recovery and beneficiary voluntary close remain. Exact local temporal boundaries have deterministic tests, and commitment `21` naturally transitioned to `AtRisk` and `Breached` at finalized timestamps. The remaining acceptance steps are tracked in `TODO.md`.

**Task 011 — Improve commitment discovery — CONTRACT DEPLOYED; RPC AND BROWSER PAGINATION VERIFIED**

The contract exposes a capped newest-first listing by sequential commitment ID; the SDK wraps it and the Console provides ten-record pages with an exclusive cursor. Testnet RPC confirmed descending/exclusive pagination, and Firefox checks confirmed the older-page control across all 21 records.

**Task 012 — Finish the public LCP Console journey — IMPLEMENTATION COMPLETE; ACCESSIBILITY ACCEPTANCE OPEN**

The app reconstructs recent historical health transitions, shows policy-derived deadlines and countdowns, and reports OutLayer public-record availability and digest bindings. Firefox checks verified the historical timeline, wallet connect/disconnect, older-page control, create/fund/activate/evaluate/recover/close/refund flow, payout, and failed-transfer retry across the documented fixtures. The app does not claim to verify the TEE quote; OutLayer's report and standalone verifier remain the verification path. `CONSOLE-GUIDE.md` and `TESTING.md` document reproduction. The repository is public, satisfying the PRD's public-documentation gate.

---

# 18. Definition of Done

LCP Technical Specification v0.1 is implemented when:

- The Rust state model compiles.
- All temporal unit tests pass.
- A commitment activates on NEAR testnet.
- A real OutLayer execution returns a validated verdict.
- Evidence expires according to the contract's policy.
- The commitment becomes AtRisk and then Breached.
- A financial claim is rejected while Breached.
- Fresh evidence restores Healthy.
- An eligible future claim succeeds.
- Double settlement and callback replay are rejected.
- The public repository documents the implementation and its limitations.

**Final engineering principle:**

The evaluator reports evidence.

The temporal engine determines health.

The consequence layer enforces rights.

**No layer may bypass the others.**
