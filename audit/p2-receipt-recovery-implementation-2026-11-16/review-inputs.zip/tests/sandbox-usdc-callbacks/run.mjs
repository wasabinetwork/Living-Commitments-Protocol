import assert from "node:assert/strict";
import { createHash, createPrivateKey, generateKeyPairSync, sign } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  DEFAULT_PRIVATE_KEY,
  DEFAULT_PUBLIC_KEY,
  Sandbox,
} from "near-sandbox";

const here = fileURLToPath(new URL(".", import.meta.url));
const repoRoot = resolve(here, "../..");
const wasmDir = join(repoRoot, "target/wasm32-unknown-unknown/release");
const sandboxCache = process.env.LCP_SANDBOX_BINARY_DIR;
if (sandboxCache) process.env.DIR_TO_DOWNLOAD_BINARY = sandboxCache;

const CORE_ID = "lcp-core-sandbox.sandbox";
const TOKEN_ID = "mock-usdc.sandbox";
const NO_CODE_TOKEN_ID = "no-code-token.sandbox";
const ORDER_A_ID = "order-a.sandbox";
const ORDER_B_ID = "order-b.sandbox";
const CASH_RECIPIENT_ID = "cash-recipient.sandbox";
const RECIPIENT_ID = "recipient.sandbox";
const AMOUNT = 1_000_000n;
const INITIAL_TOKEN_BALANCE = 10_000_000n;
const ONE_NEAR = 10n ** 24n;
const NATIVE_STORAGE_MARGIN_BUFFER = 5n * 10n ** 22n;
const TERA = 1_000_000_000_000n;
const privateKeyPrefix = Buffer.from("302e020100300506032b657004220420", "hex");
let rpcId = 0;

function base58Decode(text) {
  const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let value = 0n;
  for (const char of text) {
    const digit = alphabet.indexOf(char);
    if (digit < 0) throw new Error(`Invalid base58 character ${char}`);
    value = value * 58n + BigInt(digit);
  }
  const bytes = value === 0n ? Buffer.alloc(0) : Buffer.from(value.toString(16).padStart(Math.ceil(value.toString(16).length / 2) * 2, "0"), "hex");
  let leadingZeroes = 0;
  while (text[leadingZeroes] === "1") leadingZeroes += 1;
  return Buffer.concat([Buffer.alloc(leadingZeroes), bytes]);
}

function base58Encode(bytes) {
  const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let value = BigInt(`0x${bytes.toString("hex") || "0"}`);
  let encoded = "";
  while (value > 0n) {
    const remainder = Number(value % 58n);
    encoded = alphabet[remainder] + encoded;
    value /= 58n;
  }
  let leadingZeroes = 0;
  while (bytes[leadingZeroes] === 0) leadingZeroes += 1;
  return "1".repeat(leadingZeroes) + encoded;
}

function u32(value) {
  const result = Buffer.alloc(4);
  result.writeUInt32LE(value);
  return result;
}

function u64(value) {
  const result = Buffer.alloc(8);
  result.writeBigUInt64LE(BigInt(value));
  return result;
}

function u128(value) {
  const result = Buffer.alloc(16);
  const integer = BigInt(value);
  result.writeBigUInt64LE(integer & ((1n << 64n) - 1n), 0);
  result.writeBigUInt64LE(integer >> 64n, 8);
  return result;
}

function borshString(value) {
  const bytes = Buffer.from(value, "utf8");
  return Buffer.concat([u32(bytes.length), bytes]);
}

function borshBytes(value) {
  return Buffer.concat([u32(value.length), value]);
}

function publicKeyBytes(publicKey) {
  const [curve, encoded] = publicKey.split(":");
  assert.equal(curve, "ed25519");
  const bytes = base58Decode(encoded);
  assert.equal(bytes.length, 32);
  return Buffer.concat([Buffer.from([0]), bytes]);
}

function keyFromNearStrings(privateKey, publicKey) {
  const [privateCurve, privateEncoded] = privateKey.split(":");
  const [publicCurve, publicEncoded] = publicKey.split(":");
  assert.equal(privateCurve, "ed25519");
  assert.equal(publicCurve, "ed25519");
  const secret = base58Decode(privateEncoded);
  const publicBytes = base58Decode(publicEncoded);
  assert.equal(secret.length, 64);
  assert.equal(publicBytes.length, 32);
  assert.deepEqual(secret.subarray(32), publicBytes);
  return {
    publicKey,
    publicKeyBytes: publicBytes,
    privateKeyObject: createPrivateKey({
      key: Buffer.concat([privateKeyPrefix, secret.subarray(0, 32)]),
      format: "der",
      type: "pkcs8",
    }),
  };
}

function newKey() {
  const pair = generateKeyPairSync("ed25519");
  const seed = pair.privateKey.export({ format: "der", type: "pkcs8" }).subarray(-32);
  const publicBytes = pair.publicKey.export({ format: "der", type: "spki" }).subarray(-32);
  return {
    publicKey: `ed25519:${base58Encode(publicBytes)}`,
    publicKeyBytes: publicBytes,
    privateKeyObject: pair.privateKey,
    privateKey: `ed25519:${base58Encode(Buffer.concat([seed, publicBytes]))}`,
  };
}

function actionCreateAccount() {
  return Buffer.from([0]);
}

function actionDeploy(code) {
  return Buffer.concat([Buffer.from([1]), borshBytes(code)]);
}

function actionFunctionCall(method, args = {}, gas = 30n * TERA, deposit = 0n) {
  return Buffer.concat([
    Buffer.from([2]),
    borshString(method),
    borshBytes(Buffer.from(JSON.stringify(args), "utf8")),
    u64(gas),
    u128(deposit),
  ]);
}

function actionTransfer(amount) {
  return Buffer.concat([Buffer.from([3]), u128(amount)]);
}

function actionAddFullAccessKey(publicKey) {
  return Buffer.concat([Buffer.from([5]), publicKeyBytes(publicKey), u64(0), Buffer.from([1])]);
}

function serializeTransaction({ signerId, key, nonce, receiverId, blockHash, actions }) {
  // NEAR preserves the untagged TransactionV0 encoding for backward compatibility.
  return Buffer.concat([
    borshString(signerId),
    publicKeyBytes(key.publicKey),
    u64(nonce),
    borshString(receiverId),
    base58Decode(blockHash),
    u32(actions.length),
    ...actions,
  ]);
}

function isFailedExecution(value) {
  return Boolean(value && typeof value === "object" && Object.hasOwn(value, "Failure"));
}

function hasFailedExecution(result) {
  return isFailedExecution(result.status)
    || (result.receipts_outcome ?? []).some((receipt) => isFailedExecution(receipt.outcome?.status));
}

function assertTransactionSucceeded(result, description) {
  if (isFailedExecution(result.status)) {
    throw new Error(`${description} failed:\n${JSON.stringify(result, null, 2)}`);
  }
}

async function main() {
  const rootKey = keyFromNearStrings(DEFAULT_PRIVATE_KEY, DEFAULT_PUBLIC_KEY);
  const coreKey = newKey();
  const tokenKey = newKey();
  const noCodeTokenKey = newKey();
  const orderAKey = newKey();
  const orderBKey = newKey();
  const cashRecipientKey = newKey();
  const sandbox = await Sandbox.start({ version: "2.14.0" });
  const fixtures = {};

  async function rpc(method, params) {
    const response = await fetch(sandbox.rpcUrl, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: ++rpcId, method, params }),
    });
    const body = await response.json();
    if (!response.ok || body.error) {
      throw new Error(`${method} RPC failed: ${JSON.stringify(body.error ?? body)}`);
    }
    return body.result;
  }

  async function sendTransaction(signerId, key, receiverId, actions, description, options = {}) {
    const block = await rpc("block", { finality: "final" });
    let nonce = options.nonce;
    if (nonce === undefined) {
      const accessKey = await rpc("query", {
        request_type: "view_access_key",
        account_id: signerId,
        public_key: key.publicKey,
        finality: "optimistic",
      });
      nonce = BigInt(accessKey.nonce) + 1n;
    }
    const transactionBytes = serializeTransaction({
      signerId,
      key,
      nonce,
      receiverId,
      blockHash: block.header.hash,
      actions,
    });
    const digest = createHash("sha256").update(transactionBytes).digest();
    const signature = sign(null, digest, key.privateKeyObject);
    const signedTransaction = Buffer.concat([transactionBytes, Buffer.from([0]), signature]);
    const method = options.broadcastMethod ?? "broadcast_tx_commit";
    const result = await rpc(method, [signedTransaction.toString("base64")]);
    if (method === "broadcast_tx_commit") {
      if (options.expectFailure) {
        assert.ok(hasFailedExecution(result),
          `${description} should fail its execution receipt: ${JSON.stringify(result.status)}`);
        console.log(`EXPECTED FAILURE RECEIPT ${description}: ${JSON.stringify({
          status: result.status,
          transaction_status: result.transaction_outcome?.outcome?.status,
          receipt_statuses: (result.receipts_outcome ?? []).map((receipt) => ({
            status: receipt.outcome?.status,
            logs: receipt.outcome?.logs,
          })),
        })}`);
        console.log(`PASS expected failure ${description}: ${result.transaction.hash}`);
        return result;
      }
      assertTransactionSucceeded(result, description);
      console.log(`PASS ${description}: ${result.transaction.hash}`);
      return result;
    }
    console.log(`SUBMITTED ${description}: ${result}`);
    return result;
  }

  async function createSubaccount(accountId, key) {
    await sendTransaction("sandbox", rootKey, accountId, [
      actionCreateAccount(),
      actionTransfer(30n * 10n ** 24n),
      actionAddFullAccessKey(key.publicKey),
    ], `create ${accountId}`);
  }

  async function functionCall(accountId, key, method, args, gas = 30n * TERA, deposit = 0n, options = {}) {
    return sendTransaction(accountId, key, accountId, [
      actionFunctionCall(method, args, gas, deposit),
    ], `${accountId}.${method}`, options);
  }

  async function accountBalance(accountId, finality = "final") {
    const result = await rpc("query", {
      request_type: "view_account",
      account_id: accountId,
      finality,
    });
    return BigInt(result.amount);
  }

  function returnedJson(result) {
    const statuses = [
      ...(result.receipts_outcome ?? []).map((receipt) => receipt.outcome?.status),
      result.status,
    ];
    const success = statuses.find((status) => status && Object.hasOwn(status, "SuccessValue"));
    assert.ok(success, "transaction has no function-call return value");
    return JSON.parse(Buffer.from(success.SuccessValue, "base64").toString("utf8"));
  }

  async function view(accountId, method, args = {}) {
    const result = await rpc("query", {
      request_type: "call_function",
      account_id: accountId,
      method_name: method,
      args_base64: Buffer.from(JSON.stringify(args), "utf8").toString("base64"),
      finality: "optimistic",
    });
    return JSON.parse(Buffer.from(result.result).toString("utf8"));
  }

  async function accountCodeHash(accountId) {
    try {
      const result = await rpc("query", {
        request_type: "view_code",
        account_id: accountId,
        finality: "final",
      });
      return result.hash;
    } catch (error) {
      if (String(error).includes("NO_CONTRACT_CODE")) return null;
      throw error;
    }
  }

  async function waitFor(description, check, timeoutMs = 30_000) {
    const deadline = Date.now() + timeoutMs;
    let last;
    while (Date.now() < deadline) {
      last = await check();
      if (last.done) return last.value;
      await new Promise((resolve) => setTimeout(resolve, 400));
    }
    throw new Error(`Timed out waiting for ${description}; last state: ${JSON.stringify(last)}`);
  }

  async function deployAndWait(accountId, key, wasm, expectedCodeHash, description) {
    const transactionHash = await sendTransaction(
      accountId,
      key,
      accountId,
      [actionDeploy(wasm)],
      description,
      { broadcastMethod: "broadcast_tx_async" },
    );
    await waitFor(`${description} code`, async () => {
      const codeHash = await accountCodeHash(accountId);
      return codeHash === expectedCodeHash
        ? { done: true, value: codeHash }
        : { done: false, value: codeHash };
    }, 90_000);
    console.log(`PASS ${description} finalized with the expected code hash`);
    return { transaction_hash: String(transactionHash), near_code_hash: expectedCodeHash };
  }

  async function submitAndWaitForTransaction(accountId, key, receiverId, actions, description) {
    const transactionHash = await sendTransaction(
      accountId,
      key,
      receiverId,
      actions,
      description,
      { broadcastMethod: "broadcast_tx_async" },
    );
    const result = await waitFor(`${description} receipt`, async () => {
      try {
        const status = await rpc("tx", [transactionHash, accountId]);
        const complete = status.status && (
          Object.hasOwn(status.status, "SuccessValue")
          || Object.hasOwn(status.status, "Failure")
        );
        return complete
          ? { done: true, value: status }
          : { done: false, value: status.status };
      } catch (error) {
        if (/unknown transaction|does not exist|not found/i.test(String(error))) {
          return { done: false, value: String(error) };
        }
        throw error;
      }
    }, 120_000);
    assertTransactionSucceeded(result, description);
    result.transaction ??= { hash: transactionHash };
    return result;
  }

  async function escrow(commitmentId) {
    return view(CORE_ID, "get_escrow_status", { commitment_id: String(commitmentId) });
  }

  async function tranche(commitmentId) {
    return view(CORE_ID, "get_tranche", { commitment_id: String(commitmentId), epoch: "0" });
  }

  async function nativeCashSnapshot() {
    const cash = (await view(CORE_ID, "sandbox_native_cash_snapshot", {})).map(BigInt);
    assert.equal(cash[8], 0n, "native cash ledger must have no storage shortfall");
    return cash;
  }

  function nativeFreeMargin(cash) {
    return cash[0] - cash[1] - cash[2] - cash[3] - cash[4]
      - cash[5] - cash[6] - cash[7];
  }

  async function setNativeFreeMargin(target, description) {
    const marginTx = await submitAndWaitForTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall("sandbox_set_native_free_margin", {
        target_free_balance_yocto: target.toString(),
      }, 100n * TERA)],
      `set free native cash margin for ${description}`,
    );
    const measurements = returnedJson(marginTx).map(BigInt);
    assert.equal(measurements[3] - measurements[5], target,
      `${description}: fixture did not set the requested native-cash margin`);
    assert.equal(measurements[6], target,
      `${description}: fixture did not preserve the requested target`);
    const after = await nativeCashSnapshot();
    const freeAfter = nativeFreeMargin(after);
    assert.equal(freeAfter, target,
      `${description}: view snapshot reports ${freeAfter}, expected ${target}`);
    assert.equal(after[6], measurements[5],
      `${description}: fixture liability differs from the ledger snapshot`);
    return {
      target_free_margin_yocto: target.toString(),
      account_balance_yocto: measurements[0].toString(),
      storage_cost_yocto: measurements[1].toString(),
      required_without_fixture_yocto: measurements[2].toString(),
      available_without_fixture_yocto: measurements[3].toString(),
      previous_fixture_liability_yocto: measurements[4].toString(),
      fixture_liability_yocto: measurements[5].toString(),
      free_after_fixture_yocto: freeAfter.toString(),
      cash_snapshot: after.map(String),
    };
  }

  async function clearNativeFreeMargin(description) {
    const cash = await nativeCashSnapshot();
    const available_without_fixture = cash[0] - cash[1] - cash[2] - cash[3]
      - cash[4] - cash[5] - cash[7];
    const cleared = await setNativeFreeMargin(available_without_fixture, description);
    const after = await nativeCashSnapshot();
    assert.equal(after[6], 0n, `${description}: fixture recovery-credit liability remains`);
    return cleared;
  }

  async function tokenBalance(accountId, tokenAccountId = TOKEN_ID) {
    return BigInt(await view(tokenAccountId, "ft_balance_of", { account_id: accountId }));
  }

  function assertConservation(status) {
    const funded = BigInt(status.funded_raw);
    const settled = BigInt(status.paid_raw) + BigInt(status.refunded_raw)
      + BigInt(status.pending_raw) + BigInt(status.free_raw);
    assert.equal(funded, settled, "raw-unit escrow conservation failed");
  }

  try {
    const nodeStatus = await rpc("status", []);
    assert.equal(nodeStatus.protocol_version, 88, "fixture requires NEAR protocol 88");
    fixtures.node = {
      sandbox_version: "2.14.0",
      protocol_version: nodeStatus.protocol_version,
      chain_id: nodeStatus.chain_id,
      genesis_hash: nodeStatus.genesis_hash,
      version: nodeStatus.version,
    };

    const coreWasm = await readFile(join(wasmDir, "lcp_core.wasm"));
    const tokenWasm = await readFile(join(wasmDir, "sandbox_mock_ft.wasm"));
    const tokenVariantBWasm = await readFile(join(wasmDir, "sandbox_mock_ft_variant_b.wasm"));
    const codeHashV1 = base58Encode(createHash("sha256").update(tokenWasm).digest());
    const codeHashV2 = base58Encode(createHash("sha256").update(tokenVariantBWasm).digest());
    const codeHashCore = base58Encode(createHash("sha256").update(coreWasm).digest());
    fixtures.artifacts = {
      lcp_core_fixture: {
        wasm_sha256: createHash("sha256").update(coreWasm).digest("hex"),
        near_code_hash: codeHashCore,
      },
      mock_ft_variant_a: {
        wasm_sha256: createHash("sha256").update(tokenWasm).digest("hex"),
        near_code_hash: codeHashV1,
      },
      mock_ft_variant_b: {
        wasm_sha256: createHash("sha256").update(tokenVariantBWasm).digest("hex"),
        near_code_hash: codeHashV2,
      },
    };
    await createSubaccount(CORE_ID, coreKey);
    await createSubaccount(TOKEN_ID, tokenKey);
    await createSubaccount(NO_CODE_TOKEN_ID, noCodeTokenKey);
    await createSubaccount(ORDER_A_ID, orderAKey);
    await createSubaccount(ORDER_B_ID, orderBKey);
    await createSubaccount(CASH_RECIPIENT_ID, cashRecipientKey);

    fixtures.core_deploy_transaction = await deployAndWait(
      CORE_ID,
      coreKey,
      coreWasm,
      codeHashCore,
      "deploy fixture core",
    );
    await functionCall(CORE_ID, coreKey, "new", {});

    const marginTopUpYocto = 1n * 10n ** 24n;
    const coreBalanceBeforeTopUp = await accountBalance(CORE_ID, "optimistic");
    const topUpTransaction = await sendTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionTransfer(marginTopUpYocto)],
      "fund isolated core native liquidity margin",
    );
    assert.ok(!hasFailedExecution(topUpTransaction), "native liquidity top-up must settle successfully");
    const coreBalanceAfterTopUp = await waitFor("isolated core liquidity top-up", async () => {
      const balance = await accountBalance(CORE_ID, "optimistic");
      return balance >= coreBalanceBeforeTopUp + marginTopUpYocto
        ? { done: true, value: balance }
        : {
          done: false,
          value: {
            minimum: (coreBalanceBeforeTopUp + marginTopUpYocto).toString(),
            observed: balance.toString(),
          },
        };
    });
    fixtures.native_liquidity_funding = {
      transaction_hash: topUpTransaction.transaction.hash,
      source_account: "sandbox",
      target_account: CORE_ID,
      action: "Transfer",
      amount_yocto: marginTopUpYocto.toString(),
      target_balance_before: coreBalanceBeforeTopUp.toString(),
      target_balance_after: coreBalanceAfterTopUp.toString(),
      observed_balance_delta: (coreBalanceAfterTopUp - coreBalanceBeforeTopUp).toString(),
    };
    console.log("PASS a plain NEAR transfer funds isolated-instance liquidity margin without a contract call");

    const cashRecipientBalanceBeforeProbe = await accountBalance(CASH_RECIPIENT_ID);
    const underfundedProbe = await functionCall(CORE_ID, coreKey, "sandbox_probe_native_cash_gate", {
      recipient: CASH_RECIPIENT_ID,
      outflow_yocto: "1",
      underfund_by_one: true,
    }, 100n * TERA, 0n, { expectFailure: true });
    assert.ok(hasFailedExecution(underfundedProbe),
      "one-yocto-underfunded promise must fail at the native cash gate");
    const cashRecipientBalanceAfterFailedProbe = await accountBalance(CASH_RECIPIENT_ID);
    assert.equal(cashRecipientBalanceAfterFailedProbe, cashRecipientBalanceBeforeProbe,
      "failed solvency check must roll back the native transfer promise");

    const balancedProbe = await functionCall(CORE_ID, coreKey, "sandbox_probe_native_cash_gate", {
      recipient: CASH_RECIPIENT_ID,
      outflow_yocto: "1",
      underfund_by_one: false,
    }, 100n * TERA);
    const [balanceBefore, balanceAfterPromise, storageCost, liability] = returnedJson(balancedProbe).map(BigInt);
    assert.equal(balanceAfterPromise, balanceBefore,
      "guest account_balance should remain the pre-promise receipt balance in this runtime");
    assert.equal(storageCost + liability + 1n, balanceBefore,
      "the explicit outflow reserve must make the exact-balance control solvent");
    const cashRecipientBalanceAfterExactProbe = await waitFor("exactly funded one-yocto transfer", async () => {
      const balance = await accountBalance(CASH_RECIPIENT_ID);
      return balance === cashRecipientBalanceBeforeProbe + 1n
        ? { done: true, value: balance }
        : { done: false, value: balance.toString() };
    });
    fixtures.native_cash_gate = {
      underfunded: {
        transaction_hash: underfundedProbe.transaction.hash,
        receipt_outcomes: underfundedProbe.receipts_outcome.map((outcome) => ({
          id: outcome.id,
          status: outcome.outcome?.status,
        })),
        recipient_balance_before: cashRecipientBalanceBeforeProbe.toString(),
        recipient_balance_after: cashRecipientBalanceAfterFailedProbe.toString(),
      },
      exact_balance: {
        transaction_hash: balancedProbe.transaction.hash,
        receipt_measurements: {
          balance_before: balanceBefore.toString(),
          balance_after_promise: balanceAfterPromise.toString(),
          storage_cost: storageCost.toString(),
          liability: liability.toString(),
        },
        recipient_balance_before: cashRecipientBalanceBeforeProbe.toString(),
        recipient_balance_after: cashRecipientBalanceAfterExactProbe.toString(),
      },
    };
    console.log("PASS protocol-88 cash gate explicitly reserves promise outflows, rejects one yocto short, and settles the exact-balance control");
    if (process.env.LCP_CASH_GATE_ONLY === "1") {
      console.log("All focused native cash gate checks passed; no public network was used.");
      return;
    }

    const nativeCommitmentId = "90";
    const nativeTrancheAmount = 10n ** 22n;
    await functionCall(CORE_ID, coreKey, "sandbox_seed_native_claimable_commitment", {
      commitment_id: nativeCommitmentId,
      beneficiary: CASH_RECIPIENT_ID,
      amount_yocto: nativeTrancheAmount.toString(),
    }, 100n * TERA);
    await functionCall(CORE_ID, coreKey, "sandbox_set_next_transfer_recipient", {
      commitment_id: nativeCommitmentId,
      recipient: "missing-native-recipient.sandbox",
    });

    const nativeClaimAction = () => actionFunctionCall(
      "claim_tranche",
      { commitment_id: nativeCommitmentId },
      100n * TERA,
      1n * 10n ** 24n,
    );
    const failedNativeClaimTx = await submitAndWaitForTransaction(
      CASH_RECIPIENT_ID,
      cashRecipientKey,
      CORE_ID,
      [nativeClaimAction()],
      "native tranche claim with missing recipient",
    );
    const failedNativeClaim = await waitFor("failed native payout callback", async () => {
      const [tranche, escrowState, cash] = await Promise.all([
        view(CORE_ID, "get_tranche", {
          commitment_id: nativeCommitmentId,
          epoch: "0",
        }),
        view(CORE_ID, "get_escrow_status", { commitment_id: nativeCommitmentId }),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (tranche?.status === "Failed"
        && BigInt(cash[2]) === nativeTrancheAmount
        && BigInt(cash[3]) === 0n
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { tranche, escrowState, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: {
          tranche_status: tranche?.status,
          escrow_state: escrowState,
          cash: cash.map(String),
        },
      };
    });
    const failedNativeClaimReceiptTree = await rpc("tx", [
      failedNativeClaimTx.transaction.hash,
      CASH_RECIPIENT_ID,
    ]);
    assert.ok(
      failedNativeClaimReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"tranche_transfer_failed"'))),
      "native failure receipt tree must include the successful failure-reconciliation callback",
    );
    assert.ok(
      failedNativeClaimReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"excess_storage_refund_sent"'))),
      "native failure receipt tree must include the successful excess-refund callback",
    );
    assert.equal(failedNativeClaim.escrowState.pending_yocto, "0");
    assert.equal(failedNativeClaim.escrowState.free_yocto, nativeTrancheAmount.toString());
    assert.ok(
      failedNativeClaim.cash[0] >= failedNativeClaim.cash[1] + failedNativeClaim.cash[2],
      "failed native transfer must leave the recorded escrow liability cash-backed",
    );
    console.log("NATIVE_CLAIM_RETRY_PRE_STATE", JSON.stringify({
      cash: failedNativeClaim.cash.map(String),
      escrow: failedNativeClaim.escrowState,
      tranche_status: failedNativeClaim.tranche.status,
    }));

    const successfulNativeClaimTx = await submitAndWaitForTransaction(
      CASH_RECIPIENT_ID,
      cashRecipientKey,
      CORE_ID,
      [nativeClaimAction()],
      "native tranche claim retry",
    );
    const successfulNativeClaim = await waitFor("successful native payout callback", async () => {
      const [tranche, escrowState, cash] = await Promise.all([
        view(CORE_ID, "get_tranche", {
          commitment_id: nativeCommitmentId,
          epoch: "0",
        }),
        view(CORE_ID, "get_escrow_status", { commitment_id: nativeCommitmentId }),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (tranche?.status === "Paid"
        && BigInt(escrowState.paid_yocto) === nativeTrancheAmount
        && BigInt(cash[2]) === 0n
        && BigInt(cash[3]) === 0n
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { tranche, escrowState, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: {
          tranche_status: tranche?.status,
          escrow_state: escrowState,
          cash: cash.map(String),
        },
      };
    });
    const successfulNativeClaimReceiptTree = await rpc("tx", [
      successfulNativeClaimTx.transaction.hash,
      CASH_RECIPIENT_ID,
    ]);
    assert.ok(
      successfulNativeClaimReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"tranche_paid"'))),
      "native retry receipt tree must include the successful payout-reconciliation callback",
    );
    assert.ok(
      successfulNativeClaimReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"excess_storage_refund_sent"'))),
      "native retry receipt tree must include the successful excess-refund callback",
    );
    assert.equal(successfulNativeClaim.escrowState.pending_yocto, "0");
    assert.equal(successfulNativeClaim.escrowState.free_yocto, "0");
    assert.ok(
      successfulNativeClaim.cash[0] >= successfulNativeClaim.cash[1],
      "successful native payout must leave account balance above storage cost",
    );
    fixtures.native_claim_callback = {
      commitment_id: nativeCommitmentId,
      amount_yocto: nativeTrancheAmount.toString(),
      failure: {
        transaction_hash: failedNativeClaimTx.transaction.hash,
        transaction_outcome: failedNativeClaimReceiptTree.transaction_outcome,
        receipts_outcome: failedNativeClaimReceiptTree.receipts_outcome,
        recipient: "missing-native-recipient.sandbox",
        tranche_status: failedNativeClaim.tranche.status,
        escrow_state: failedNativeClaim.escrowState,
        cash_snapshot: failedNativeClaim.cash.map(String),
      },
      retry_success: {
        transaction_hash: successfulNativeClaimTx.transaction.hash,
        transaction_outcome: successfulNativeClaimReceiptTree.transaction_outcome,
        receipts_outcome: successfulNativeClaimReceiptTree.receipts_outcome,
        tranche_status: successfulNativeClaim.tranche.status,
        escrow_state: successfulNativeClaim.escrowState,
        cash_snapshot: successfulNativeClaim.cash.map(String),
      },
    };
    console.log("PASS production native claim path preserves failed escrow and clears liability after successful retry");

    const nativeRefundCommitmentId = "91";
    const nativeRefundAmount = nativeTrancheAmount;
    const nativeRefundSafeMargin = ONE_NEAR + (2n * nativeRefundAmount)
      + NATIVE_STORAGE_MARGIN_BUFFER;
    const operationsFunded = nativeTrancheAmount * 2n;
    const operationsSpent = nativeTrancheAmount;
    await functionCall(CORE_ID, coreKey, "sandbox_seed_closed_native_refund_commitment", {
      commitment_id: nativeRefundCommitmentId,
      sponsor: "sandbox",
      beneficiary: CASH_RECIPIENT_ID,
      escrow_amount_yocto: nativeRefundAmount.toString(),
      operations_funded_yocto: operationsFunded.toString(),
      operations_spent_yocto: operationsSpent.toString(),
    }, 100n * TERA);

    await functionCall(CORE_ID, coreKey, "sandbox_set_next_transfer_recipient", {
      commitment_id: nativeRefundCommitmentId,
      recipient: "missing-native-refund-recipient.sandbox",
    });
    const nativeLiquidityMargin = {};
    nativeLiquidityMargin.escrow_one_transfer_gate = await setNativeFreeMargin(
      nativeRefundAmount,
      "native escrow refund one-transfer margin gate",
    );
    const insufficientNativeEscrowRefundTx = await sendTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall(
        "refund_remaining",
        { commitment_id: nativeRefundCommitmentId },
        100n * TERA,
        ONE_NEAR,
      )],
      "native escrow refund with one-transfer free margin",
      { expectFailure: true },
    );
    const insufficientNativeEscrowRefundLogs = (insufficientNativeEscrowRefundTx.receipts_outcome ?? [])
      .flatMap((receipt) => receipt.outcome?.logs ?? []);
    assert.ok(insufficientNativeEscrowRefundLogs.some((log) =>
      log.includes("SANDBOX_CASH_GATE_FAILED")),
    "one-transfer native escrow margin must fail at the cash solvency gate");
    assert.ok(!insufficientNativeEscrowRefundLogs.some((log) =>
      log.includes('"event":"escrow_refund_requested"')),
    "underfunded escrow refund must stop before its payout promise is requested");
    const insufficientNativeEscrowRefundReceipt = insufficientNativeEscrowRefundTx.receipts_outcome
      ?.find((receipt) => receipt.outcome?.executor_id === CORE_ID
        && isFailedExecution(receipt.outcome?.status));
    assert.ok(insufficientNativeEscrowRefundReceipt,
      "insufficient native refund margin must fail in the core receipt");
    const escrowStateAtInsufficientMargin = await escrow(nativeRefundCommitmentId);
    const cashAtInsufficientEscrowMargin = await nativeCashSnapshot();
    assert.equal(escrowStateAtInsufficientMargin.pending_yocto, "0",
      "insufficient native margin must not leave an escrow refund pending");
    assert.equal(escrowStateAtInsufficientMargin.free_yocto, nativeRefundAmount.toString(),
      "insufficient native margin must preserve the refundable escrow amount");
    assert.deepEqual(
      cashAtInsufficientEscrowMargin.map(String),
      nativeLiquidityMargin.escrow_one_transfer_gate.cash_snapshot,
      "insufficient native refund margin must preserve contract balance and liabilities",
    );
    nativeLiquidityMargin.escrow_one_transfer_gate_result = {
      transaction_hash: insufficientNativeEscrowRefundTx.transaction.hash,
      receipt_logs: insufficientNativeEscrowRefundLogs,
      receipt_outcomes: insufficientNativeEscrowRefundTx.receipts_outcome?.map((receipt) => ({
        id: receipt.id,
        executor_id: receipt.outcome?.executor_id,
        status: receipt.outcome?.status,
        receipt_ids: receipt.outcome?.receipt_ids,
      })),
      escrow_state: escrowStateAtInsufficientMargin,
      cash_snapshot: cashAtInsufficientEscrowMargin.map(String),
    };
    nativeLiquidityMargin.escrow_failure = await setNativeFreeMargin(
      nativeRefundSafeMargin,
      "native escrow refund failure with callback reserve",
    );
    const failedNativeEscrowRefundTx = await submitAndWaitForTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall(
        "refund_remaining",
        { commitment_id: nativeRefundCommitmentId },
        100n * TERA,
        ONE_NEAR,
      )],
      "native escrow refund with missing recipient",
    );
    const failedNativeEscrowRefund = await waitFor("failed native escrow refund callback", async () => {
      const [escrowState, cash, receiptTree] = await Promise.all([
        escrow(nativeRefundCommitmentId),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
        rpc("tx", [failedNativeEscrowRefundTx.transaction.hash, "sandbox"]),
      ]);
      if (escrowState?.pending_yocto === "0"
        && escrowState.free_yocto === nativeRefundAmount.toString()
        && escrowState.refunded_yocto === "0"
        && BigInt(cash[2]) === nativeRefundAmount
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { escrowState, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: {
          escrowState,
          cash: cash.map(String),
          receipts: receiptTree.receipts_outcome?.map(({ id, outcome }) => ({
            id,
            executor_id: outcome.executor_id,
            status: outcome.status,
            logs: outcome.logs,
          })),
        },
      };
    });
    const failedNativeEscrowRefundReceiptTree = await rpc("tx", [
      failedNativeEscrowRefundTx.transaction.hash,
      "sandbox",
    ]);
    assert.ok(
      failedNativeEscrowRefundReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"escrow_refund_failed"'))),
      "native escrow refund receipt tree must include the failure-reconciliation callback",
    );
    assert.ok(
      failedNativeEscrowRefundReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"excess_storage_refund_sent"'))),
      "native escrow refund receipt tree must include the excess-refund callback",
    );

    nativeLiquidityMargin.escrow_retry = await setNativeFreeMargin(
      nativeRefundSafeMargin,
      "native escrow refund retry",
    );
    const successfulNativeEscrowRefundTx = await submitAndWaitForTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall(
        "refund_remaining",
        { commitment_id: nativeRefundCommitmentId },
        100n * TERA,
        ONE_NEAR,
      )],
      "native escrow refund retry",
    );
    const successfulNativeEscrowRefund = await waitFor("successful native escrow refund callback", async () => {
      const [escrowState, cash] = await Promise.all([
        escrow(nativeRefundCommitmentId),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (escrowState?.pending_yocto === "0"
        && escrowState.free_yocto === "0"
        && escrowState.refunded_yocto === nativeRefundAmount.toString()
        && BigInt(cash[2]) === 0n
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { escrowState, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: { escrowState, cash: cash.map(String) },
      };
    });
    const successfulNativeEscrowRefundReceiptTree = await rpc("tx", [
      successfulNativeEscrowRefundTx.transaction.hash,
      "sandbox",
    ]);
    assert.ok(
      successfulNativeEscrowRefundReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"escrow_refunded"'))),
      "native escrow refund retry must include the successful settlement callback",
    );
    fixtures.native_escrow_refund_callback = {
      commitment_id: nativeRefundCommitmentId,
      amount_yocto: nativeRefundAmount.toString(),
      failure: {
        transaction_hash: failedNativeEscrowRefundTx.transaction.hash,
        transaction_outcome: failedNativeEscrowRefundReceiptTree.transaction_outcome,
        receipts_outcome: failedNativeEscrowRefundReceiptTree.receipts_outcome,
        escrow_state: failedNativeEscrowRefund.escrowState,
        cash_snapshot: failedNativeEscrowRefund.cash.map(String),
      },
      retry_success: {
        transaction_hash: successfulNativeEscrowRefundTx.transaction.hash,
        transaction_outcome: successfulNativeEscrowRefundReceiptTree.transaction_outcome,
        receipts_outcome: successfulNativeEscrowRefundReceiptTree.receipts_outcome,
        escrow_state: successfulNativeEscrowRefund.escrowState,
        cash_snapshot: successfulNativeEscrowRefund.cash.map(String),
      },
    };
    console.log("PASS production native escrow refund preserves liability on failure and releases it on retry");

    await functionCall(CORE_ID, coreKey, "sandbox_set_next_transfer_recipient", {
      commitment_id: nativeRefundCommitmentId,
      recipient: "missing-operations-refund-recipient.sandbox",
    });
    nativeLiquidityMargin.operations_failure = await setNativeFreeMargin(
      nativeRefundSafeMargin,
      "native operations refund failure",
    );
    const failedNativeOperationsRefundTx = await submitAndWaitForTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall(
        "refund_unused_operations",
        { commitment_id: nativeRefundCommitmentId },
        100n * TERA,
        ONE_NEAR,
      )],
      "native operations refund with missing recipient",
    );
    const failedNativeOperationsRefund = await waitFor("failed operations refund callback", async () => {
      const [commitment, cash] = await Promise.all([
        view(CORE_ID, "get_commitment", { commitment_id: nativeRefundCommitmentId }),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (commitment?.pending_transfer_count === 0
        && commitment.operations_funded_yocto === operationsFunded.toString()
        && BigInt(cash[5]) === nativeRefundAmount
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { commitment, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: { commitment, cash: cash.map(String) },
      };
    });
    const failedNativeOperationsRefundReceiptTree = await rpc("tx", [
      failedNativeOperationsRefundTx.transaction.hash,
      "sandbox",
    ]);
    assert.ok(
      failedNativeOperationsRefundReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"operations_refund_failed"'))),
      "native operations refund receipt tree must include the failure-reconciliation callback",
    );

    nativeLiquidityMargin.operations_retry = await setNativeFreeMargin(
      nativeRefundSafeMargin,
      "native operations refund retry",
    );
    const successfulNativeOperationsRefundTx = await submitAndWaitForTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall(
        "refund_unused_operations",
        { commitment_id: nativeRefundCommitmentId },
        100n * TERA,
        ONE_NEAR,
      )],
      "native operations refund retry",
    );
    const successfulNativeOperationsRefund = await waitFor("successful operations refund callback", async () => {
      const [commitment, cash] = await Promise.all([
        view(CORE_ID, "get_commitment", { commitment_id: nativeRefundCommitmentId }),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (commitment?.pending_transfer_count === 0
        && commitment.operations_funded_yocto === operationsSpent.toString()
        && BigInt(cash[5]) === 0n
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { commitment, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: { commitment, cash: cash.map(String) },
      };
    });
    const successfulNativeOperationsRefundReceiptTree = await rpc("tx", [
      successfulNativeOperationsRefundTx.transaction.hash,
      "sandbox",
    ]);
    assert.ok(
      successfulNativeOperationsRefundReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"operations_refunded"'))),
      "native operations refund retry must include the successful settlement callback",
    );
    fixtures.native_operations_refund_callback = {
      commitment_id: nativeRefundCommitmentId,
      amount_yocto: nativeRefundAmount.toString(),
      failure: {
        transaction_hash: failedNativeOperationsRefundTx.transaction.hash,
        transaction_outcome: failedNativeOperationsRefundReceiptTree.transaction_outcome,
        receipts_outcome: failedNativeOperationsRefundReceiptTree.receipts_outcome,
        operations_funded_yocto: failedNativeOperationsRefund.commitment.operations_funded_yocto,
        cash_snapshot: failedNativeOperationsRefund.cash.map(String),
      },
      retry_success: {
        transaction_hash: successfulNativeOperationsRefundTx.transaction.hash,
        transaction_outcome: successfulNativeOperationsRefundReceiptTree.transaction_outcome,
        receipts_outcome: successfulNativeOperationsRefundReceiptTree.receipts_outcome,
        operations_funded_yocto: successfulNativeOperationsRefund.commitment.operations_funded_yocto,
        cash_snapshot: successfulNativeOperationsRefund.cash.map(String),
      },
    };
    console.log("PASS production native operations refund restores spendable balance on failure and settles on retry");

    const storageRefundCredit = nativeTrancheAmount / 2n;
    await functionCall(CORE_ID, coreKey, "sandbox_seed_storage_refund_credit", {
      account_id: CASH_RECIPIENT_ID,
      amount_yocto: storageRefundCredit.toString(),
    }, 100n * TERA);
    await functionCall(CORE_ID, coreKey, "sandbox_set_next_storage_refund_recipient", {
      account_id: CASH_RECIPIENT_ID,
      recipient: "missing-storage-refund-recipient.sandbox",
    });
    nativeLiquidityMargin.storage_credit_one_transfer_gate = await setNativeFreeMargin(
      storageRefundCredit,
      "native storage-credit withdrawal one-transfer margin gate",
    );
    const insufficientStorageCreditWithdrawalTx = await sendTransaction(
      CASH_RECIPIENT_ID,
      cashRecipientKey,
      CORE_ID,
      [actionFunctionCall("withdraw_storage_refund", {}, 100n * TERA)],
      "storage-credit withdrawal with one-transfer free margin",
      { expectFailure: true },
    );
    const insufficientStorageCreditWithdrawalLogs = (insufficientStorageCreditWithdrawalTx.receipts_outcome ?? [])
      .flatMap((receipt) => receipt.outcome?.logs ?? []);
    assert.ok(insufficientStorageCreditWithdrawalLogs.some((log) =>
      log.includes("SANDBOX_CASH_GATE_FAILED")),
    "one-transfer storage-credit margin must fail at the cash solvency gate");
    assert.ok(!insufficientStorageCreditWithdrawalLogs.some((log) =>
      log.includes('"event":"service_report_refund_requested"')),
    "underfunded storage-credit withdrawal must stop before its transfer promise is requested");
    const insufficientStorageCreditWithdrawalReceipt = insufficientStorageCreditWithdrawalTx.receipts_outcome
      ?.find((receipt) => receipt.outcome?.executor_id === CORE_ID
        && isFailedExecution(receipt.outcome?.status));
    assert.ok(insufficientStorageCreditWithdrawalReceipt,
      "insufficient storage-credit margin must fail in the core receipt");
    const creditAtInsufficientMargin = await view(
      CORE_ID,
      "get_storage_refund_balance",
      { account_id: CASH_RECIPIENT_ID },
    );
    assert.equal(creditAtInsufficientMargin, storageRefundCredit.toString(),
      "insufficient storage-credit margin must preserve the withdrawal credit");
    const cashAtInsufficientCreditMargin = await nativeCashSnapshot();
    assert.deepEqual(
      cashAtInsufficientCreditMargin.map(String),
      nativeLiquidityMargin.storage_credit_one_transfer_gate.cash_snapshot,
      "insufficient storage-credit margin must preserve contract balance and liabilities",
    );
    nativeLiquidityMargin.storage_credit_one_transfer_gate_result = {
      transaction_hash: insufficientStorageCreditWithdrawalTx.transaction.hash,
      receipt_logs: insufficientStorageCreditWithdrawalLogs,
      receipt_outcomes: insufficientStorageCreditWithdrawalTx.receipts_outcome?.map((receipt) => ({
        id: receipt.id,
        executor_id: receipt.outcome?.executor_id,
        status: receipt.outcome?.status,
        receipt_ids: receipt.outcome?.receipt_ids,
      })),
      credit_yocto: creditAtInsufficientMargin,
      cash_snapshot: cashAtInsufficientCreditMargin.map(String),
    };
    nativeLiquidityMargin.storage_credit_failure = await setNativeFreeMargin(
      (2n * storageRefundCredit) + NATIVE_STORAGE_MARGIN_BUFFER,
      "native storage-credit withdrawal failure with callback reserve",
    );
    const failedStorageCreditWithdrawalTx = await submitAndWaitForTransaction(
      CASH_RECIPIENT_ID,
      cashRecipientKey,
      CORE_ID,
      [actionFunctionCall("withdraw_storage_refund", {}, 100n * TERA)],
      "storage credit withdrawal with missing recipient",
    );
    const failedStorageCreditWithdrawal = await waitFor("failed storage credit callback", async () => {
      const [credit, cash] = await Promise.all([
        view(CORE_ID, "get_storage_refund_balance", { account_id: CASH_RECIPIENT_ID }),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (credit === storageRefundCredit.toString()
        && BigInt(cash[3]) === storageRefundCredit
        && BigInt(cash[4]) === 0n) {
        return { done: true, value: { credit, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: { credit, cash: cash.map(String) },
      };
    });
    const failedStorageCreditWithdrawalReceiptTree = await rpc("tx", [
      failedStorageCreditWithdrawalTx.transaction.hash,
      CASH_RECIPIENT_ID,
    ]);
    assert.ok(
      failedStorageCreditWithdrawalReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"service_report_refund_failed"'))),
      "failed credit receipt tree must include the failure-reconciliation callback",
    );

    nativeLiquidityMargin.storage_credit_retry = await setNativeFreeMargin(
      (2n * storageRefundCredit) + NATIVE_STORAGE_MARGIN_BUFFER,
      "native storage-credit withdrawal retry",
    );
    const successfulStorageCreditWithdrawalTx = await submitAndWaitForTransaction(
      CASH_RECIPIENT_ID,
      cashRecipientKey,
      CORE_ID,
      [actionFunctionCall("withdraw_storage_refund", {}, 100n * TERA)],
      "storage credit withdrawal retry",
    );
    const successfulStorageCreditWithdrawal = await waitFor("successful storage credit callback", async () => {
      const [credit, cash] = await Promise.all([
        view(CORE_ID, "get_storage_refund_balance", { account_id: CASH_RECIPIENT_ID }),
        view(CORE_ID, "sandbox_native_cash_snapshot", {}),
      ]);
      if (credit === "0" && BigInt(cash[3]) === 0n && BigInt(cash[4]) === 0n) {
        return { done: true, value: { credit, cash: cash.map(BigInt) } };
      }
      return {
        done: false,
        value: { credit, cash: cash.map(String) },
      };
    });
    const successfulStorageCreditWithdrawalReceiptTree = await rpc("tx", [
      successfulStorageCreditWithdrawalTx.transaction.hash,
      CASH_RECIPIENT_ID,
    ]);
    assert.ok(
      successfulStorageCreditWithdrawalReceiptTree.receipts_outcome?.some(({ outcome }) =>
        outcome.executor_id === CORE_ID
          && outcome.logs?.some((log) => log.includes('"event":"service_report_refund_sent"'))),
      "credit withdrawal retry must include the successful settlement callback",
    );
    fixtures.native_storage_credit_callback = {
      account_id: CASH_RECIPIENT_ID,
      amount_yocto: storageRefundCredit.toString(),
      failure: {
        transaction_hash: failedStorageCreditWithdrawalTx.transaction.hash,
        transaction_outcome: failedStorageCreditWithdrawalReceiptTree.transaction_outcome,
        receipts_outcome: failedStorageCreditWithdrawalReceiptTree.receipts_outcome,
        credit_yocto: failedStorageCreditWithdrawal.credit,
        cash_snapshot: failedStorageCreditWithdrawal.cash.map(String),
      },
      retry_success: {
        transaction_hash: successfulStorageCreditWithdrawalTx.transaction.hash,
        transaction_outcome: successfulStorageCreditWithdrawalReceiptTree.transaction_outcome,
        receipts_outcome: successfulStorageCreditWithdrawalReceiptTree.receipts_outcome,
        credit_yocto: successfulStorageCreditWithdrawal.credit,
        cash_snapshot: successfulStorageCreditWithdrawal.cash.map(String),
      },
    };
    console.log("PASS production storage-credit withdrawal restores credit on failure and clears liability on retry");

    nativeLiquidityMargin.storage_credit_callback_oog_seed_reserve = await setNativeFreeMargin(
      ONE_NEAR + (3n * storageRefundCredit) + NATIVE_STORAGE_MARGIN_BUFFER,
      "native storage-credit callback out-of-gas fixture setup",
    );
    await functionCall(CORE_ID, coreKey, "sandbox_seed_storage_refund_credit", {
      account_id: CASH_RECIPIENT_ID,
      amount_yocto: storageRefundCredit.toString(),
    }, 100n * TERA);
    await submitAndWaitForTransaction(
      "sandbox",
      rootKey,
      CORE_ID,
      [actionFunctionCall("sandbox_set_next_storage_refund_callback_gas", {
        callback_gas_tgas: 1,
      }, 100n * TERA)],
      "configure native storage-refund callback out-of-gas fixture",
    );
    nativeLiquidityMargin.storage_credit_callback_oog = await setNativeFreeMargin(
      (2n * storageRefundCredit) + NATIVE_STORAGE_MARGIN_BUFFER,
      "native storage-credit callback out-of-gas reserve",
    );
    const cashBeforeStorageCallbackOog = await nativeCashSnapshot();
    const storageCallbackOogTx = await submitAndWaitForTransaction(
      CASH_RECIPIENT_ID,
      cashRecipientKey,
      CORE_ID,
      [actionFunctionCall("withdraw_storage_refund", {}, 100n * TERA)],
      "storage-credit withdrawal with deliberately underfunded callback gas",
    );
    const storageCallbackOogReceiptTree = await waitFor(
      "native storage-refund callback out-of-gas receipt",
      async () => {
        const tree = await rpc("tx", [
          storageCallbackOogTx.transaction.hash,
          CASH_RECIPIENT_ID,
        ]);
        const callbackReceipt = tree.receipts_outcome?.find(({ outcome }) =>
          outcome.executor_id === CORE_ID && isFailedExecution(outcome.status));
        return callbackReceipt
          ? { done: true, value: tree }
          : { done: false, value: tree.receipts_outcome?.map(({ outcome }) => ({
            executor_id: outcome.executor_id,
            status: outcome.status,
          })) };
      },
      120_000,
    );
    const storageCallbackOogReceipt = storageCallbackOogReceiptTree.receipts_outcome.find(
      ({ outcome }) => outcome.executor_id === CORE_ID && isFailedExecution(outcome.status),
    );
    assert.ok(storageCallbackOogReceipt, "missing failed native refund callback receipt");
    assert.ok(
      JSON.stringify(storageCallbackOogReceipt.outcome.status).includes("Exceeded the prepaid gas."),
      "native refund callback must fail from its deliberate gas limit",
    );
    const nativeRefundTransferReceipt = storageCallbackOogReceiptTree.receipts_outcome.find(
      ({ outcome }) => outcome.executor_id === CASH_RECIPIENT_ID
        && outcome.status && Object.hasOwn(outcome.status, "SuccessValue"),
    );
    assert.ok(nativeRefundTransferReceipt, "native refund transfer must settle before the callback OOG");
    assert.ok(
      !storageCallbackOogReceipt.outcome.logs?.some((log) =>
        log.includes('"event":"service_report_refund_sent"')
          || log.includes('"event":"service_report_refund_failed"')),
      "out-of-gas callback must not emit a refund settlement event",
    );
    const pendingAfterStorageCallbackOog = await waitFor(
      "native refund liability remains pending after callback out of gas",
      async () => {
        const [credit, cash] = await Promise.all([
          view(CORE_ID, "get_storage_refund_balance", { account_id: CASH_RECIPIENT_ID }),
          view(CORE_ID, "sandbox_native_cash_snapshot", {}),
        ]);
        const cashValues = cash.map(BigInt);
        return credit === "0" && cashValues[3] === storageRefundCredit && cashValues[4] === 0n
          ? { done: true, value: { credit, cash: cashValues } }
          : { done: false, value: { credit, cash: cash.map(String) } };
      },
      120_000,
    );
    assert.equal(
      cashBeforeStorageCallbackOog[0] - pendingAfterStorageCallbackOog.cash[0],
      storageRefundCredit,
      "successful native transfer must reduce core cash by the credited amount",
    );
    assert.ok(
      nativeFreeMargin(pendingAfterStorageCallbackOog.cash) >= 0n,
      "conservative reserve must still cover the unresolved native refund liability",
    );
    fixtures.native_storage_credit_callback_oog = {
      account_id: CASH_RECIPIENT_ID,
      amount_yocto: storageRefundCredit.toString(),
      callback_gas_tgas: 1,
      transaction_hash: storageCallbackOogTx.transaction.hash,
      transaction_outcome: storageCallbackOogReceiptTree.transaction_outcome,
      receipts_outcome: storageCallbackOogReceiptTree.receipts_outcome,
      available_credit_yocto: pendingAfterStorageCallbackOog.credit,
      cash_before_transfer: cashBeforeStorageCallbackOog.map(String),
      cash_after_callback_oog: pendingAfterStorageCallbackOog.cash.map(String),
      free_margin_after_callback_oog: nativeFreeMargin(pendingAfterStorageCallbackOog.cash).toString(),
    };
    console.log("PASS native refund transfer can settle while an out-of-gas callback leaves its liability pending and funded");
    nativeLiquidityMargin.fixture_cleanup = await clearNativeFreeMargin(
      "native callback fixture cleanup",
    );
    fixtures.native_liquidity_margin = nativeLiquidityMargin;

    fixtures.mock_ft_deploy_transaction = await deployAndWait(
      TOKEN_ID,
      tokenKey,
      tokenWasm,
      codeHashV1,
      "deploy mock NEP-141",
    );
    await functionCall(TOKEN_ID, tokenKey, "new", {
      initial_holder: CORE_ID,
      initial_balance: INITIAL_TOKEN_BALANCE.toString(),
    });
    await deployAndWait(ORDER_A_ID, orderAKey, tokenWasm, codeHashV1, "deploy action-order A");
    await functionCall(ORDER_A_ID, orderAKey, "new", {
      initial_holder: ORDER_A_ID,
      initial_balance: INITIAL_TOKEN_BALANCE.toString(),
    });
    await deployAndWait(ORDER_B_ID, orderBKey, tokenWasm, codeHashV1, "deploy action-order B");
    await functionCall(ORDER_B_ID, orderBKey, "new", {
      initial_holder: ORDER_B_ID,
      initial_balance: INITIAL_TOKEN_BALANCE.toString(),
    });

    const oOg = await functionCall(CORE_ID, coreKey, "sandbox_queue_tranche_transfer", {
      commitment_id: "1",
      token_account_id: TOKEN_ID,
      recipient: RECIPIENT_ID,
      amount_raw: AMOUNT.toString(),
      callback_gas_tgas: 2,
    }, 100n * TERA);
    assert.ok(
      (oOg.receipts_outcome ?? []).some((outcome) =>
        JSON.stringify(outcome.outcome?.status).includes("Exceeded the prepaid gas")),
      "callback receipt should explicitly fail for exceeding its prepaid gas",
    );
    await new Promise((resolve) => setTimeout(resolve, 1_500));
    const oOgEscrow = await escrow(1);
    assert.ok(oOgEscrow, "missing escrow status for callback OOG commitment");
    const oOgTranche = await tranche(1);
    assert.equal(oOgTranche.status, "Pending");
    assert.equal(BigInt(oOgEscrow.pending_raw), AMOUNT);
    assert.equal(BigInt(oOgEscrow.paid_raw), 0n);
    assert.equal(BigInt(oOgEscrow.free_raw), 0n);
    assert.equal(await tokenBalance(RECIPIENT_ID), AMOUNT, "token receipt should have succeeded before callback OOG");
    assertConservation(oOgEscrow);
    console.log(`PASS callback OOG leaves the token liability reserved (${oOg.transaction.hash})`);

    await functionCall(TOKEN_ID, tokenKey, "set_fail_transfers", { fail: true });
    await functionCall(CORE_ID, coreKey, "sandbox_queue_tranche_transfer", {
      commitment_id: "2",
      token_account_id: TOKEN_ID,
      recipient: RECIPIENT_ID,
      amount_raw: AMOUNT.toString(),
      callback_gas_tgas: 20,
    }, 100n * TERA);
    const failedEscrow = await waitFor("explicit token failure callback", async () => {
      const state = await escrow(2);
      return state && state.pending_raw === "0" && (await tranche(2))?.status === "Failed"
        ? { done: true, value: state }
        : { done: false, value: state };
    });
    assert.equal(BigInt(failedEscrow.free_raw), AMOUNT);
    assert.equal(BigInt(failedEscrow.paid_raw), 0n);
    assertConservation(failedEscrow);
    assert.equal(await tokenBalance(RECIPIENT_ID), AMOUNT);
    console.log("PASS explicit token failure restores free escrow and marks the tranche Failed");

    await functionCall(TOKEN_ID, tokenKey, "set_fail_transfers", { fail: false });
    const retryTx = await functionCall(CORE_ID, coreKey, "sandbox_queue_tranche_transfer", {
      commitment_id: "2",
      token_account_id: TOKEN_ID,
      recipient: RECIPIENT_ID,
      amount_raw: AMOUNT.toString(),
      callback_gas_tgas: 20,
    }, 100n * TERA);
    const retryEscrow = await waitFor("successful retry callback", async () => {
      const state = await escrow(2);
      return state && BigInt(state.paid_raw) === AMOUNT && state.pending_raw === "0"
        ? { done: true, value: state }
        : { done: false, value: state };
    });
    assert.equal((await tranche(2)).status, "Paid");
    assert.equal(BigInt(retryEscrow.free_raw), 0n);
    assert.equal(await tokenBalance(RECIPIENT_ID), AMOUNT * 2n);
    assertConservation(retryEscrow);
    const successReceipt = retryTx.receipts_outcome?.find(
      ({ outcome }) => outcome.executor_id === TOKEN_ID,
    );
    assert.ok(successReceipt, "missing successful token receipt");
    assert.ok(
      successReceipt.outcome.status && Object.hasOwn(successReceipt.outcome.status, "SuccessValue"),
      `successful token receipt must have SuccessValue status, got ${JSON.stringify(successReceipt.outcome.status)}`,
    );
    assert.equal(successReceipt.outcome.metadata?.contracts?.[0]?.local, codeHashV1);
    fixtures.successful_control = {
      outer_transaction_hash: retryTx.transaction.hash,
      receipts_outcome: retryTx.receipts_outcome,
      expected_token_code_hash: codeHashV1,
    };
    console.log("PASS successful retry pays once and consumes the reservation");

    const beforeNoCode = {
      sender: await tokenBalance(CORE_ID),
      recipient: await tokenBalance(RECIPIENT_ID),
    };
    const noCodeTx = await submitAndWaitForTransaction(
      CORE_ID,
      coreKey,
      CORE_ID,
      [actionFunctionCall("sandbox_queue_tranche_transfer", {
        commitment_id: "7",
        token_account_id: NO_CODE_TOKEN_ID,
        recipient: RECIPIENT_ID,
        amount_raw: AMOUNT.toString(),
        callback_gas_tgas: 20,
      }, 100n * TERA, 0n)],
      "queue transfer to account without token code",
    );
    const noCodeReceipt = noCodeTx.receipts_outcome?.find(
      ({ outcome }) => outcome.executor_id === NO_CODE_TOKEN_ID,
    );
    assert.ok(noCodeReceipt, "missing pre-execution token receipt outcome");
    assert.ok(isFailedExecution(noCodeReceipt.outcome.status), "no-code token receipt must fail");
    const noCodeEscrow = await waitFor("no-code token failure callback", async () => {
      const state = await escrow(7);
      return state && state.pending_raw === "0" && (await tranche(7))?.status === "Failed"
        ? { done: true, value: state }
        : { done: false, value: state };
    });
    assert.equal(await tokenBalance(CORE_ID), beforeNoCode.sender);
    assert.equal(await tokenBalance(RECIPIENT_ID), beforeNoCode.recipient);
    assert.equal(BigInt(noCodeEscrow.free_raw), AMOUNT);
    assertConservation(noCodeEscrow);
    fixtures.pre_execution_failure = {
      outer_transaction_hash: noCodeTx.transaction.hash,
      receipts_outcome: noCodeTx.receipts_outcome,
      token_balances_before: Object.fromEntries(
        Object.entries(beforeNoCode).map(([accountId, value]) => [accountId, value.toString()]),
      ),
      token_balances_after: {
        [CORE_ID]: (await tokenBalance(CORE_ID)).toString(),
        [RECIPIENT_ID]: (await tokenBalance(RECIPIENT_ID)).toString(),
      },
      escrow: noCodeEscrow,
    };
    console.log("PASS missing-code token receipt fails before contract execution with no token balance changes");

    await functionCall(TOKEN_ID, tokenKey, "set_fail_after_mutation", { fail: true });
    const beforePanic = {
      sender: await tokenBalance(CORE_ID),
      recipient: await tokenBalance(RECIPIENT_ID),
    };
    const panicTx = await functionCall(CORE_ID, coreKey, "sandbox_queue_tranche_transfer", {
      commitment_id: "8",
      token_account_id: TOKEN_ID,
      recipient: RECIPIENT_ID,
      amount_raw: AMOUNT.toString(),
      callback_gas_tgas: 20,
    }, 100n * TERA);
    const panicReceipt = panicTx.receipts_outcome?.find(
      ({ outcome }) => outcome.executor_id === TOKEN_ID,
    );
    assert.ok(panicReceipt, "missing post-mutation token receipt outcome");
    assert.ok(isFailedExecution(panicReceipt.outcome.status), "post-mutation token receipt must fail");
    const panicEscrow = await waitFor("post-mutation panic callback", async () => {
      const state = await escrow(8);
      return state && state.pending_raw === "0" && (await tranche(8))?.status === "Failed"
        ? { done: true, value: state }
        : { done: false, value: state };
    });
    assert.equal(await tokenBalance(CORE_ID), beforePanic.sender, "sender write must roll back");
    assert.equal(await tokenBalance(RECIPIENT_ID), beforePanic.recipient, "recipient write must roll back");
    assert.equal(BigInt(panicEscrow.free_raw), AMOUNT);
    assertConservation(panicEscrow);
    fixtures.post_mutation_failure = {
      outer_transaction_hash: panicTx.transaction.hash,
      receipts_outcome: panicTx.receipts_outcome,
      token_balances_before: Object.fromEntries(
        Object.entries(beforePanic).map(([accountId, value]) => [accountId, value.toString()]),
      ),
      token_balances_after: {
        [CORE_ID]: (await tokenBalance(CORE_ID)).toString(),
        [RECIPIENT_ID]: (await tokenBalance(RECIPIENT_ID)).toString(),
      },
      escrow: panicEscrow,
    };
    await functionCall(TOKEN_ID, tokenKey, "set_fail_after_mutation", { fail: false });
    console.log("PASS token receipt panic after balance writes rolls back both token writes");

    const functionCallAction = actionFunctionCall("ft_transfer", {
      receiver_id: RECIPIENT_ID,
      amount: AMOUNT.toString(),
      memo: null,
    }, 25n * TERA, 1n);
    const deployV2Action = actionDeploy(tokenVariantBWasm);
    assert.notEqual(codeHashV1, codeHashV2, "action-order fixture code versions must differ");

    const transferThenDeploy = await submitAndWaitForTransaction(
      ORDER_A_ID,
      orderAKey,
      ORDER_A_ID,
      [functionCallAction, deployV2Action],
      "action order A transfer then deploy B",
    );
    const transferThenDeployReceipt = transferThenDeploy.receipts_outcome?.find(
      ({ outcome }) => outcome.executor_id === ORDER_A_ID,
    );
    assert.ok(transferThenDeployReceipt, "missing transfer-then-deploy receipt");
    const firstOrderContracts = transferThenDeployReceipt.outcome.metadata?.contracts;
    assert.ok(Array.isArray(firstOrderContracts), "protocol-88 V4 contract metadata is missing");
    assert.equal(firstOrderContracts[0]?.local, codeHashV1, "transfer action should execute A before deploy B");
    assert.equal(firstOrderContracts[1]?.local, codeHashV1, "the deployment action begins under the existing A code");
    assert.equal(await tokenBalance(RECIPIENT_ID, ORDER_A_ID), AMOUNT);
    fixtures.action_order_transfer_then_deploy = {
      transaction_hash: transferThenDeploy.transaction.hash,
      receipts_outcome: transferThenDeploy.receipts_outcome,
      expected_code_hash: codeHashV1,
      observed_contract_metadata: firstOrderContracts,
    };

    const deployThenTransfer = await submitAndWaitForTransaction(
      ORDER_B_ID,
      orderBKey,
      ORDER_B_ID,
      [deployV2Action, functionCallAction],
      "action order B deploy then transfer",
    );
    const deployThenTransferReceipt = deployThenTransfer.receipts_outcome?.find(
      ({ outcome }) => outcome.executor_id === ORDER_B_ID,
    );
    assert.ok(deployThenTransferReceipt, "missing deploy-then-transfer receipt");
    const secondOrderContracts = deployThenTransferReceipt.outcome.metadata?.contracts;
    assert.ok(Array.isArray(secondOrderContracts), "protocol-88 V4 contract metadata is missing");
    assert.equal(secondOrderContracts[0]?.local, codeHashV1, "the deployment action begins under the existing A code");
    assert.equal(secondOrderContracts[1]?.local, codeHashV2, "transfer action should execute B after deployment");
    assert.equal(await tokenBalance(RECIPIENT_ID, ORDER_B_ID), AMOUNT);
    assert.equal(await view(ORDER_A_ID, "ft_contract_version", {}), 2);
    assert.equal(await view(ORDER_B_ID, "ft_contract_version", {}), 2);
    fixtures.action_order_deploy_then_transfer = {
      transaction_hash: deployThenTransfer.transaction.hash,
      receipts_outcome: deployThenTransfer.receipts_outcome,
      expected_code_hash: codeHashV2,
      observed_contract_metadata: secondOrderContracts,
    };
    fixtures.action_order_code_hashes = { variant_a: codeHashV1, variant_b: codeHashV2 };
    console.log("PASS protocol-88 V4 metadata binds transfer-before-deploy to A and deploy-before-transfer to B");

    const concurrentAccessKey = await rpc("query", {
      request_type: "view_access_key",
      account_id: CORE_ID,
      public_key: coreKey.publicKey,
      finality: "optimistic",
    });
    for (let offset = 0; offset < 4; offset += 1) {
      const commitmentId = 3 + offset;
      await sendTransaction(CORE_ID, coreKey, CORE_ID, [
        actionFunctionCall("sandbox_queue_tranche_transfer", {
          commitment_id: String(commitmentId),
          token_account_id: TOKEN_ID,
          recipient: RECIPIENT_ID,
          amount_raw: AMOUNT.toString(),
          callback_gas_tgas: 20,
        }, 100n * TERA),
      ], `queue concurrent commitment ${commitmentId}`, {
        nonce: BigInt(concurrentAccessKey.nonce) + BigInt(offset) + 1n,
        broadcastMethod: "broadcast_tx_async",
      });
    }
    for (const commitmentId of [3, 4, 5, 6]) {
      const state = await waitFor(`concurrent commitment ${commitmentId}`, async () => {
        const value = await escrow(commitmentId);
        return value && BigInt(value.paid_raw) === AMOUNT && value.pending_raw === "0"
          ? { done: true, value }
          : { done: false, value };
      });
      assert.equal((await tranche(commitmentId)).status, "Paid");
      assertConservation(state);
    }
    assert.equal(await tokenBalance(RECIPIENT_ID), AMOUNT * 6n);
    console.log("PASS four concurrent equal-amount transfers settle independently");
    console.log("PASS final recipient balance equals six successful token transfers (6,000,000 raw units)");

    if (process.env.LCP_FIXTURE_OUTPUT) {
      const fixture = {
        fixture_schema: "lcp.protocol-88-receipt-rollback.v1",
        captured_at: new Date().toISOString(),
        node: fixtures.node,
        wasm_artifacts: fixtures.artifacts,
        scenarios: {
          native_liquidity_funding: fixtures.native_liquidity_funding,
          native_cash_gate: fixtures.native_cash_gate,
          native_claim_callback: fixtures.native_claim_callback,
          native_escrow_refund_callback: fixtures.native_escrow_refund_callback,
          native_operations_refund_callback: fixtures.native_operations_refund_callback,
          native_storage_credit_callback: fixtures.native_storage_credit_callback,
          native_storage_credit_callback_oog: fixtures.native_storage_credit_callback_oog,
          native_liquidity_margin: fixtures.native_liquidity_margin,
          core_deploy_transaction: fixtures.core_deploy_transaction,
          pre_execution_failure: fixtures.pre_execution_failure,
          post_mutation_failure: fixtures.post_mutation_failure,
          successful_control: fixtures.successful_control,
          action_order_transfer_then_deploy: fixtures.action_order_transfer_then_deploy,
          action_order_deploy_then_transfer: fixtures.action_order_deploy_then_transfer,
          action_order_code_hashes: fixtures.action_order_code_hashes,
        },
      };
      await writeFile(process.env.LCP_FIXTURE_OUTPUT, `${JSON.stringify(fixture, null, 2)}\n`);
      console.log(`WROTE protocol-88 raw receipt fixture: ${process.env.LCP_FIXTURE_OUTPUT}`);
    }
    console.log("All local NEAR Sandbox callback checks passed; no testnet transaction was sent.");
  } finally {
    await sandbox.tearDown();
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
